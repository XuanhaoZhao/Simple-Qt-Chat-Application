#ifndef IMFRIENDBUTTON_H
#define IMFRIENDBUTTON_H

#include <QPushButton>

class IMFriendButton : public QPushButton
{
    Q_OBJECT
public:
    IMFriendButton(QWidget *parent = 0);
    IMFriendButton(const QString &text, QWidget *parent = 0);
    void init(const QString &text = nullptr);
    ~IMFriendButton();


protected:
    void mousePressEvent(QMouseEvent *e);
    
signals:
    
public slots:

private:

};

#endif // IMFRIENDBUTTON_H
