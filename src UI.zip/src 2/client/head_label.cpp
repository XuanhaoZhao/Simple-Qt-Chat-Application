#include "head_label.h"
#include <QFile>
#include <QMessageBox>
head_label::head_label(QWidget *parent) : QLabel(parent)
{

}
void head_label:: mouseReleaseEvent(QMouseEvent *ev)
{
    if(ev->button() ==Qt::LeftButton)
    {
        QString path = QFileDialog::getOpenFileName(this,tr("请选择替换的头像图片"),".",tr("Image Files(*.jpg *.png)"));
        if(!path.isEmpty()){
            QImage* img = new QImage;
            if(!(img->load(path))) //加载图像
            {
               QMessageBox::information(this, tr("打开图像失败"), tr("打开图像失败!"));
               delete img;
               return;
            }
            delete img;
            emit image_change(path);
        }
    }
}
