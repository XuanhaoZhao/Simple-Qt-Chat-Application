#ifndef IMFRIENDLISTWIDGET_H
#define IMFRIENDLISTWIDGET_H

#include <QWidget>

class QVBoxLayout;
class QScrollArea;

class IMFriendListWidget : public QWidget
{
    Q_OBJECT
public:
    IMFriendListWidget(QWidget *parent = 0);
    void addItem(QWidget *item);
    void cleanItem();

signals:

public slots:

protected:

private:
    QVBoxLayout *m_layout;
    QWidget *m_contentsWidget;
    QScrollArea *m_friendsScrollArea;

};

#endif // IMFRIENDLISTWIDGET_H
