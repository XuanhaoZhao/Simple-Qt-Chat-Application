#include "database.h"

Database::Database() {
    if(QSqlDatabase::contains("qt_sql_default_connection")) {
        db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("server.db");

    if (!db.open()) {
        qDebug() << "Error: Failed to connect database." << db.lastError();
    } else {
        qDebug() << "Succeed to connect database.";
    }

    QSqlQuery query;

    if(!query.exec("create table if not exists users(username varchar primary key, password varchar, nickname varchar, groupslist varchar, headImage varchar);")) {
        qDebug() << "Error: Fail to create table."<< query.lastError();
    } else {
        qDebug() << "Table users OK!";
    }

//    if(!query.exec("create table if not exists groups(id int primary key, nickname varchar, owner varchar, members varchar);")) {
//        qDebug() << "Error: Fail to create table."<< query.lastError();
//    } else {
//        qDebug() << "Table groups OK!";
//    }
    query.finish();
}

Database::~Database() {
    db.close();
}

std::vector<User> Database::selectUser() {
    QSqlQuery query;
    std::vector<User> retval;
    if(query.exec("select * from users;")) {
        while(query.next()) {
            User user;
            user.username = query.value(0).toString();
            user.password = query.value(1).toString();
            user.nickname = query.value(2).toString();
            user.groupslist = query.value(3).toString();
            user.headImage = query.value(4).toString();
            retval.push_back(user);
        }
        return retval;
    }
    qDebug() << query.lastError();
    query.finish();
    return retval;
}

User *Database::selectUserByUsername(QString username) {
    QSqlQuery query;
    query.prepare("select * from users where username == :username;");
    query.bindValue(":username", QString(username));
    query.exec();

    if(query.next()) {
        User *retval = new User;
        retval->username = username;
        retval->password = query.value(1).toString();
        retval->nickname = query.value(2).toString();
        retval->groupslist = query.value(3).toString();
        retval->headImage = query.value(4).toString();
        return retval;
    }

    qDebug() << query.lastError();
    query.finish();
    return NULL;
}

bool Database::insertUser(User user) {
    QSqlQuery query;
    query.prepare("insert into users (username, password, nickname, groupslist, headImage) values (:username, :password, :nickname, :groupslist, :headImage);");
    query.bindValue(":username", user.username);
    query.bindValue(":password", user.password);
    query.bindValue(":nickname", user.nickname);
    query.bindValue(":groupslist", user.groupslist);
    query.bindValue(":headImage", user.headImage);

    qDebug() << "binding headImage ..." << user.headImage.size();

    if(query.exec()) {
        return true;
    }

    qDebug() << query.lastError();
    query.finish();
    return false;
}

bool Database::changeUserImg(User user) {
    QSqlQuery query;
   bool isok_query = query.prepare("update users set headimage = :headimage where username = :username ;");

 if(true == isok_query)qDebug()<<"change query is ok";
 else qDebug()<<"change query is wrong";
//qDebug()<<user.headimage;
    query.bindValue(":username", user.username);
    query.bindValue(":headimage", user.headImage);
    if(query.exec()) {
        return true;
    }

    qDebug() << query.lastError();
    query.finish();
    return false;
}
