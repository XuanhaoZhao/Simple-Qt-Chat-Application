#include "protocol.h"

Protocol::Protocol() {
    this->socket = new QWebSocket();
}

Protocol::~Protocol() {
    delete this->socket;
}

bool Protocol::connectServer(QString ws) {
    this->socket->open(QUrl(ws));
    connect(this->socket, SIGNAL(connected()), this, SLOT(onConnected()));
    return true;
}

void Protocol::onConnected() {
    connect(this->socket, SIGNAL(textMessageReceived(QString)), this, SLOT(onTextMessageReceived(QString)));
}


void Protocol::onTextMessageReceived(QString data) {
qDebug() << data;
    this->router(data);
}

bool Protocol::sendSignIn(QString username, QString password) { // send 01
    if(username != "" && password != "") {
        QJsonObject res;
        res.insert("package", "signIn");
        res.insert("username", username);
        res.insert("password", password);
        this->me.username = username;
        this->me.password = password;
        QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    return false;
}

bool Protocol::sendSignUp(QString username, QString password, QString nickname, QString headImage) { // send 02
    if(username != "" && password != "" && nickname != "") {
        QFile file("signUp.jpg");

        QJsonObject res;
        res.insert("package", "signUp");
        res.insert("username", username);
        res.insert("password", password);
        res.insert("nickname", nickname);
        if(file.exists()) {
            file.open(QFile::ReadOnly);
qDebug() << "File size :" << file.size();
            res.insert("face", QString(file.readAll().toBase64()));
            file.close();
            file.remove();
        }
        res.insert("headImage", headImage);
qDebug() << "head image size : " << headImage.size();
        QJsonDocument resDoc(res);
qDebug() << "Sign Up Information :" << resDoc.toJson().length() ;
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    return false;
}

bool Protocol::sendGetFriendsList() { // send 03
qDebug() << "sendGetFriendsList";
    QJsonObject res;
    res.insert("package", "getFriendsList");
    res.insert("token", this->token);
    QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    return true;
}

bool Protocol::sendGetGroupsList()
{
qDebug() << "sendGetGroupsList";
        QJsonObject res;
        res.insert("package", "getGroupsList");
        res.insert("token", this->token);
        QJsonDocument resDoc(res);
 qDebug() << resDoc.toJson();
        socket->sendTextMessage(resDoc.toJson());
        return true;
}



bool Protocol::sendFriendMessage(Message message) { // send 06
    if(message.text != "") {
        QJsonObject msg;
        msg.insert("dst", message.dst);
        msg.insert("type", message.type);
        msg.insert("text", message.text);
        QJsonObject res;
        res.insert("package", "sendFriendMessage");
        res.insert("token", this->token);
        res.insert("message", msg);
        QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    return false;
}

bool Protocol::sendFaceSignIn(QString face_base64) { // send 13
    if(face_base64 != "") {
qDebug() << "Sending Picture...";
        QJsonObject res;
qDebug() << "face_str" << face_base64.length() << "[SEP]";
        res.insert("package", "faceSignIn");
        res.insert("face", face_base64);
        //qDebug() << face_base64;
        QJsonDocument resDoc(res);
qDebug() << resDoc.toJson().length();
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    else {
qDebug() << "Empty Picture.";
    }
    return false;
}

bool Protocol::sendGetFriendsHeadImage()
{
qDebug() << "sendGetFriendsHeadImage";
    QJsonObject res;
    res.insert("package", "getFriendsHeadImage");
    res.insert("token", this->token);
    QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    return true;
}

bool Protocol::sendAddFriendRequest(QString target)
{
qDebug() << "Client sendAddFriendRequest : " << target;
    for (std::vector<QString>::iterator it = this->friendsUsername.begin(); it != this->friendsUsername.end(); ++ it)
    {
        if (target == *it) {
qDebug() << "Already Exists in Friend List" ;
            emit duplicatedFriends();
            return false;
        }
    }
    QJsonObject res;
    res.insert("package", "addFriendRequest");
    res.insert("target", target);
    res.insert("token", this->token);
    QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    return true;
}

bool Protocol::sendConnectFriends(QString target)
{
    sendGetFriendsList();
    for (std::vector<QString>::iterator it = this->friendsUsername.begin(); it != this->friendsUsername.end(); ++ it)
    {
        if (target == *it) {
qDebug() << "Already Friends!";
            return  false;
        }
    }
qDebug() << "sendConnectFriends";
    QJsonObject res;
    res.insert("package", "sendConnectFriends");
    res.insert("token", this->token);
    res.insert("target", target);
    QJsonDocument resDoc(res);
    qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    sendGetFriendsList();
    return true;
}

bool Protocol::sendInviteMember(QString groupname)
{
    sendGetGroupsList();
    for (std::vector<QString>::iterator it = this->groupsName.begin(); it != this->groupsName.end(); ++ it)
    {
        if (groupname == *it) {
qDebug() << "Already Group Members!";
            return  false;
        }
    }
qDebug() << "sendInviteMember";
    QJsonObject res;
    res.insert("package", "sendInviteMember");
    res.insert("token", this->token);
    res.insert("groupname", groupname);
    QJsonDocument resDoc(res);
    qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    sendGetGroupsList();
    return true;
}

bool Protocol::sendShakeAction(QString source, QString target)
{
qDebug() << "sendGetFriendsHeadImage";
    QJsonObject res;
    res.insert("package", "shakeAction");
    res.insert("source", source);
    res.insert("target", target);
    res.insert("token", this->token);
    QJsonDocument resDoc(res);
qDebug() << resDoc.toJson();
    socket->sendTextMessage(resDoc.toJson());
    return true;
}

bool Protocol::sendCreateGroup(QString groupname)
{
    if(groupname != "")
    {
        QJsonObject res;
        res.insert("package", "createGroup");
        res.insert("username", me.username);
        res.insert("token", this->token);
        res.insert("groupname", groupname);
        QFile headfile("://assets/Lock.jpg");
        headfile.open(QFile::ReadOnly);
        QString defaultGroupImage =(QString)(headfile.readAll().toBase64());
        res.insert("groupimage", defaultGroupImage);
        QJsonDocument resDoc(res);
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    else
        return false;
}

bool Protocol::denyAddFriendRequest(QString target)
{
    QString source = this->me.username;
    record.deleteAddFriendRequestRecord(source ,target);
    emit needRefreshAddFriendRequestList();
    return true;
}

bool Protocol::denyAddGroupMemberRequest(QString groupname)
{
    QString source = this->me.username;
    record.deleteAddGroupMemberRequestRecord(source ,groupname);
    emit needRefreshAddFriendRequestList();
    emit needRefreshAddGroupMemberRequestList();
    return true;
}

bool Protocol::sendGetGroupUsers(QString groupname)
{
    QJsonObject res;
    res.insert("package", "getGroupUsers");
    res.insert("token", this->token);
    res.insert("groupname",groupname);
    QJsonDocument resDoc(res);
    socket->sendTextMessage(resDoc.toJson());
    return true;
}

bool Protocol::sendGroupMessage(Message message)
{
qDebug() << "sendGroupMessage";
    if(message.text != "") {
        QJsonObject msg;
        msg.insert("src", message.src);
        msg.insert("dst", message.dst);
        msg.insert("type", message.type);
        msg.insert("text", message.text);
        QJsonObject res;
        res.insert("package", "sendGroupMessage");
        res.insert("token", this->token);
        res.insert("message", msg);
        QJsonDocument resDoc(res);
    qDebug() << resDoc.toJson();
        socket->sendTextMessage(resDoc.toJson());
        return true;
    }
    return false;
}

bool Protocol::sendAddGroupMemberRequest(QString target, QString groupname)
{
qDebug() << "Client sendAddGroupMemberRequest : " << target << " " << groupname;
            if (this->me.username == target) {
qDebug() << "Already Exists in Group List" ;
                emit duplicatedGroups();
                return false;
            }
        QJsonObject res;
        res.insert("package", "addGroupMemberRequest");
        res.insert("target", target);
        res.insert("groupname", groupname);
        res.insert("token", this->token);
        QJsonDocument resDoc(res);
    qDebug() << resDoc.toJson();
        socket->sendTextMessage(resDoc.toJson());
        return true;
}


void Protocol::router(QString data) {
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString action = req.value("package").toString();
        if(action == "signIn") { // 01
            recvSignIn(data);
        } else if(action == "signUp") { // 02
            recvSignUp(data);
        } else if(action == "getFriendsList") { // 03
            recvGetFriendsList(data);
        } else if(action == "recvFriendMessage") { // 08
            recvFriendMessage(data);
        } else if (action == "getFriendsHeadImage") {
            recvGetFriendsHeadImage(data);
        } else if (action == "recvAddFriendRequest") {
            recvAddFriendRequest(data);
        } else if (action == "recvConnectFriends") {
            recvConnectFriends(data);
        } else if (action == "REFRESH_FRIENDS_LIST") {
            sendGetFriendsList();
            sendGetFriendsHeadImage();
        } else if (action == "SHAKE_ACTION") {
            deliverShakeAction(data);
        } else if (action == "addFriendRequest") {
            recvAddFriendRequestReply(data);
        } else if (action == "recvCreateGroup") {
            recvCreateGroup(data);
        } else if (action == "recvGetGroupUsers") {
            recvGetGroupUsers(data);
        } else if (action == "recvGroupMessage") {
            recvGroupMessage(data);
        } else if (action == "recvGetGroupsList") {
            recvGetGroupsList(data);
        } else if (action == "recvAddGroupMemberRequest") {
            recvAddGroupMemberRequest(data);
        } else if (action == "recvInviteMember") {
            recvInviteMember(data);
        } else if (action == "addGroupMemberRequest") {
            recvAddGroupMemberRequestReply(data);
        }
    }
}

void Protocol::image_change(QString filename)
{
  QFile file(filename);
  QJsonObject res;
  file.open(QFile::ReadOnly);
  me.headImage =(QString)(file.readAll().toBase64());
  res.insert("headImage", me.headImage);

  file.close();
  res.insert("package", "changeImg");
  res.insert("username", me.username);
  res.insert("password", me.password);
  res.insert("nickname", me.nickname);
  QJsonDocument resDoc(res);
  socket->sendTextMessage(resDoc.toJson());
emit proimage_change(me.headImage);
}


void Protocol::recvSignIn(QString data) { // recv 01
qDebug() << "recvSignIn";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
            QString username = req.value("username").toString();
            QString nickname = req.value("nickname").toString();
            QString token = req.value("token").toString();
            QString headImage = req.value("headImage").toString();

            this->me.headImage = headImage;
qDebug() << headImage.size();
            this->me.username = username;
            this->me.nickname = nickname;
            this->token = token;
            emit signInSuccess();
        } else {
            emit signInFailed();
        }
    }
}


void Protocol::recvSignUp(QString data) { // recv 02
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
            emit signUpSuccess();
        } else {
            emit signUpFailed();
        }
    }
}

void Protocol::recvGetFriendsList(QString data) { // recv 03
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
            QJsonArray friends = req.value("friends").toArray();
            this->friendsUsername.clear();
            this->friendsNickname.clear();
            for(int i=0; i<friends.count(); ++i) {
                this->friendsUsername.push_back(friends.at(i).toObject().value("username").toString());
                this->friendsNickname[friends.at(i).toObject().value("username").toString()] = friends.at(i).toObject().value("nickname").toString();
            }
            emit getFriendsListSuccess();
        }
    }
}

void Protocol::recvFriendMessage(QString data) { // recv 08
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QJsonObject message = req.value("message").toObject();

        QString time = message.value("time").toString();
        QString src = message.value("src").toString();
        QString type = message.value("type").toString();
        QString text = message.value("text").toString();
        Message msg;
        msg.time = QDateTime::fromString(time, "yyyy-MM-dd hh:mm:ss");
        msg.src = src;
        msg.dst = this->me.username;
        msg.type = type;
        msg.text = text;
        record.insertRecordByUsername(me.username, msg.src, msg);
        if(openWindowWith != msg.src) {
            ++friendsNewMessage[msg.src];
        }
        emit needRefreshFriendsList();
        emit needRefreshMessage();
qDebug() << "Message Received : " << msg.text;
    }
}

void Protocol::recvGetFriendsHeadImage(QString data)
{
qDebug() << "recvGetFriendsHeadImage...";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
            QJsonArray headImages = req.value("headImages").toArray();
qDebug() << headImages.size();
            // this->friendsUsername.clear();
            this->friendsHeadImage.clear();
qDebug() << "Friends Count : " << headImages.count();
            for(int i=0; i<headImages.count(); ++i) {
                //  this->friendsUsername.push_back(friends.at(i).toObject().value("username").toString());
                this->friendsHeadImage[headImages.at(i).toObject().value("username").toString()] = headImages.at(i).toObject().value("headImage").toString();
qDebug() << "Receiving " << i << "th head image " << this->friendsHeadImage[headImages.at(i).toObject().value("username").toString()].size();
            }
            emit getFriendsHeadImageSuccess();
        }
    }
}

void Protocol::recvAddFriendRequest(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QJsonObject message = req.value("message").toObject();

        QString time = message.value("time").toString();
        QString src = message.value("src").toString();
        QString dst = message.value("dst").toString();
        QString type = message.value("type").toString();
        QString text = message.value("text").toString();
        Message msg;
        msg.time = QDateTime::fromString(time, "yyyy-MM-dd hh:mm:ss");
        msg.src = src;
        msg.dst = dst;
        msg.type = type;
        msg.text = text;
        std::vector<Message> requests = record.selectAddFriendRecordByUsername(msg.dst);
        if (requests.size() >= 1) {
            for (std::vector<Message>::iterator it = requests.begin(); it != requests.end(); ++ it)
            {
                if (it->src == msg.src) {
                    return;
                }
            }
        }
        record.insertAddFriendRecordByUsername(msg.dst, msg);

        emit needRefreshFriendsList();
        emit needRefreshAddFriendRequestList();
qDebug() << "Add Friend Request Received From " << msg.src;
    }
}

void Protocol::recvConnectFriends(QString data)
{
qDebug() << "Connect Success";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString target = req.value("target").toString();
        QString source = req.value("source").toString();
        record.deleteAddFriendRequestRecord(source ,target);
        sendGetFriendsList();
        emit validationCommitted();
        emit needRefreshFriendsList();
        emit needRefreshMessage();
    }
}

void Protocol::deliverShakeAction(QString data)
{
qDebug() << "deliverShakeAction";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
qDebug() << "ShakeActionSignal emitting...";
            QString target = req.value("target").toString();
            QString source = req.value("source").toString();
            emit needShakeAction (source);
        }
    }
}

void Protocol::recvAddFriendRequestReply(QString data)
{
qDebug() << "recvAddFriendRequestReply";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        emit addFriendRequestResult (result);
    }
}

void Protocol::recvAddGroupMemberRequestReply(QString data)
{
qDebug() << "recvAddFriendRequestReply";
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();

        //record.deleteAddGroupMemberRequestRecord(groupname, username);
        //record.deleteAddFriendRequestRecord(source ,target);
        emit addGroupMemberRequestResult(result);
    }
}

void Protocol::recvCreateGroup(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString groupname = req.value("groupname").toString();
        this->groupsName.push_back(groupname);
qDebug()<<"The Newly Built Group Name is "<<groupsName.back();
        emit creatGroupSuccess();
    }
}

void Protocol::recvGetGroupUsers(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString memberslist = req.value("memberslist").toString();
         emit getGroupUsersSucess(memberslist);
    }
}

void Protocol::recvGroupMessage(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QJsonObject message = req.value("message").toObject();

        QString time = message.value("time").toString();
        QString src = message.value("src").toString();
        QString type_str = message.value("type").toString();
        QStringList type_strlist = type_str.split(",");
        QString type = type_str.at(0);
qDebug() << "Type : " << type;
        QString text = message.value("text").toString();
        Message msg;
        msg.time = QDateTime::fromString(time, "yyyy-MM-dd hh:mm:ss");
        msg.src = src;
        msg.dst = this->me.username;
        msg.type = type;
        msg.text = text;
        //record.insertRecordByUsername(me.username, msg.src, msg);
        if(openWindowWith != msg.src) {
            ++groupsNewMessage[msg.src];
        }
        emit needRefreshGroupsList();
        emit needRefreshGroupMessage();
qDebug() << "Message Received : " << msg.text;
    }
}

void Protocol::recvGetGroupsList(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QString result = req.value("result").toString();
        if(result == "success") {
            QJsonArray groups = req.value("groups").toArray();
            this->groupsName.clear();
            this->groupsImage.clear();
            for(int i=0; i<groups.count(); ++i) {
                this->groupsName.push_back(groups.at(i).toObject().value("groupname").toString());
                this->groupsImage[groups.at(i).toObject().value("groupname").toString()] = groups.at(i).toObject().value("groupimage").toString();
            }
            emit getGroupsListSuccess();
        }
    }
}

void Protocol::recvAddGroupMemberRequest(QString data)
{
    QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
    if(reqDoc.isObject()) {
        QJsonObject req = reqDoc.object();
        QJsonObject message = req.value("message").toObject();

        QString time = message.value("time").toString();
        QString src = message.value("src").toString();
        QString dst = message.value("dst").toString();
        QString type = message.value("type").toString();
        QString text = message.value("text").toString();
        Message msg;
        msg.time = QDateTime::fromString(time, "yyyy-MM-dd hh:mm:ss");
        msg.src = src;
        msg.dst = dst;
        msg.type = type;
        msg.text = text;
        std::vector<Message> requests = record.selectAddGroupMemberRecordByUsername(msg.dst);
        if (requests.size() >= 1) {
            for (std::vector<Message>::iterator it = requests.begin(); it != requests.end(); ++ it)
            {
                if (it->src == msg.src) {
                    return;
                }
            }
        }
        record.insertAddGroupMemberRecordByUsername(msg.dst, msg);

        emit needRefreshGroupsList();
        emit needRefreshAddGroupMemberRequestList();
qDebug() << "Add Group Member Request Received From " << msg.src;
    }
}

void Protocol::recvInviteMember(QString data)
{
qDebug() << "Invite Success";
        QJsonDocument reqDoc = QJsonDocument::fromJson(data.toUtf8());
        if(reqDoc.isObject()) {
            QJsonObject req = reqDoc.object();
            QString groupname = req.value("groupname").toString();
            QString username = req.value("username").toString();
qDebug() << "groupname : " << groupname << " username : " << username;
            record.deleteAddGroupMemberRequestRecord(username, groupname);

            sendGetGroupsList();
            emit validationCommitted();
            emit needRefreshGroupsList();
            emit needRefreshGroupMessage();
        }
}
