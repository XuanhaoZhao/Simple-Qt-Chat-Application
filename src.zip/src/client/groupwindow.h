#ifndef GROUPWINDOW_H
#define GROUPWINDOW_H

#include <QMainWindow>
#include <QCloseEvent>
#include <QMimeData>
#include <QImageReader>
#include <QFileDialog>
#include <QMessageBox>

#include "protocol.h"
#include "group.h"
#include "addgroupmember.h"
#include "record.h"

namespace Ui {
class GroupWindow;
}

class GroupWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit GroupWindow(QWidget *parent = 0);
    ~GroupWindow();
    AddGroupMember *addGroupMember = nullptr;
    void setProtocol(Protocol *protocol);
    void setOthers(bool, QString, QString);

public:
    void setSendBtnMenu();

private slots:
    void on_exitButton_clicked();
    void on_sendButton_clicked();
    void needRefreshMessage();
    void conductShakeAction(QString);
    void on_sendPicture_clicked();
    void on_shake_clicked();
    void on_sendFile_clicked();
    void on_screen_clicked();
    void sendScreenPicture();
    void onEnterAction();
    void onEnterCtrlAction();
    void getGroupUsers(QString);
    void on_addMember_clicked();


protected:
    bool eventFilter(QObject *target, QEvent *event);
//    void dragEnterEvent(QDragEnterEvent *e);
//    void dropEvent(QDropEvent *e);

private:
    Ui::GroupWindow *ui;
    Protocol *protocol = nullptr;
    Record record;
    void textEdit_pic(QString);
    bool controlPressed = false;
    QString groupname, groupimage, creator;
    QStringList memberslist;
    bool isGroup = false;
    void refreshMessage();
    void closeEvent(QCloseEvent *event);

    QAction *m_sendAction,  *m_ctrlSendAction;
};

#endif // GROUPWINDOW_H
