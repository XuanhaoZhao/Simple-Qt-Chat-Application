﻿#ifndef COMMON_H
#define COMMON_H

enum class ChatRole
{

    Self,
    Other
};

#endif // COMMON_H
