#include "requestvalidationwindow.h"
#include "ui_requestvalidationwindow.h"
#include <QListWidgetItem>
#include "listitem.h"
#include <QPushButton>

RequestValidationWindow::RequestValidationWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RequestValidationWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("NeuTalk - Request Validation");
}

void RequestValidationWindow::setProtocol(Protocol *protocol)
{
    this->protocol = protocol;
    connect(this->protocol, &Protocol::needRefreshAddFriendRequestList, this, &RequestValidationWindow::RefreshAddFriendRequestList);
    connect(this->protocol, &Protocol::needRefreshAddGroupMemberRequestList, this, &RequestValidationWindow::RefreshAddFriendRequestList);
    connect(this->protocol, &Protocol::validationCommitted, this, &RequestValidationWindow::RefreshAddFriendRequestList);
    this->RefreshAddFriendRequestList();
}

RequestValidationWindow::~RequestValidationWindow()
{
    delete ui;
}

void RequestValidationWindow::RefreshAddFriendRequestList()
{
qDebug() << "Conduct RefreshAddFriend/GroupMemberRequestList";


    std::vector<Message> requests = record.selectAddFriendRecordByUsername(protocol->me.username);
qDebug() << "Request Size : " << requests.size();
    ui->listWidget->clear();
    for (std::vector<Message>::iterator it = requests.begin(); it != requests.end(); ++ it)
    {
        QListWidgetItem *item = new QListWidgetItem(ui->listWidget);
        item->setSizeHint(QSize(100, 60));
        ListItem *list = new ListItem(ui->listWidget, it->src, "request", "");
        list->setProperty("username", it->src);
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, list);
        //connect(list, &ListItem::needRefreshFriendRequestList, this, &RequestValidationWindow::RefreshAddFriendRequestList);
        connect(list, &ListItem::needRequestValidation, this, &RequestValidationWindow::RequestValidated);
        connect(list, &ListItem::denyAddFriendRequest, this, &RequestValidationWindow::RequestDenied);
     }

    std::vector<Message> requests_g = record.selectAddGroupMemberRecordByUsername(protocol->me.username);
qDebug() << "Request Size : " << requests_g.size();
    // ui->listWidget->clear();
    for (std::vector<Message>::iterator it = requests_g.begin(); it != requests_g.end(); ++ it)
    {
        QListWidgetItem *item = new QListWidgetItem(ui->listWidget);
        item->setSizeHint(QSize(100, 60));
        ListItem *list = new ListItem(ui->listWidget, it->src, "request", "");
        list->setProperty("groupname", it->src);
        ui->listWidget->addItem(item);
        ui->listWidget->setItemWidget(item, list);
        //connect(list, &ListItem::needRefreshFriendRequestList, this, &RequestValidationWindow::RefreshAddFriendRequestList);
        connect(list, &ListItem::needRequestValidation, this, &RequestValidationWindow::GroupInvitationRequestValidated);
        connect(list, &ListItem::denyAddFriendRequest, this, &RequestValidationWindow::GroupInvitationRequestDenied);
     }
}


void RequestValidationWindow::RequestValidated()
{
qDebug() << "Sending RequestValidated : " << sender()->property("username").toString();
    this->protocol->sendConnectFriends(sender()->property("username").toString());
}

void RequestValidationWindow::GroupInvitationRequestValidated()
{
qDebug() << "Sending RequestValidated : " << sender()->property("groupname").toString();
    this->protocol->sendInviteMember(sender()->property("groupname").toString());
}

void RequestValidationWindow::RequestDenied()
{
qDebug() << "Sending RequestDenied";
    this->protocol->denyAddFriendRequest(sender()->property("username").toString());
}

void RequestValidationWindow::GroupInvitationRequestDenied()
{
qDebug() << "Sending RequestDenied";
    this->protocol->denyAddGroupMemberRequest(sender()->property("groupname").toString());
}
