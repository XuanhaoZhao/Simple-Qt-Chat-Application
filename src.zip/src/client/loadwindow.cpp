#include "loadwindow.h"
#include "ui_loadwindow.h"

#include <QPainter>
#include <QPixmap>
#include <QLabel>
#include <QImage>

LoadWindow::LoadWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::LoadWindow) {
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

LoadWindow::~LoadWindow() {
    delete ui;
}
