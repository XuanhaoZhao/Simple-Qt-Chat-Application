#ifndef DATABASE_H
#define DATABASE_H

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

#include <QString>
#include <QDebug>

#include <vector>

#include "user.h"
#include "group.h"

class Database {
public:
    Database();
    ~Database();
    std::vector<User> selectUser();
    std::vector<Group> selectGroup();
    User *selectUserByUsername(QString username);
    Group *selectGroupByGroupName (QString);
    bool insertUser(User user);
    bool changeUserImg(User user);
    bool connectUsers(QString, QString);
    bool insertGroup(Group);
    bool changeUserGroupnamelist(QString,QString);
    bool inviteGroupMember(QString, QString);

private:
    QSqlDatabase db;
};

#endif // DATABASE_H
