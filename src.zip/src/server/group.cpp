#include "group.h"

Group::Group(QString groupName, QString creator, QString groupImage, QString membersList)
{
    this->groupName = groupName;
    this->creator = creator;
    this->groupImage = groupImage;
    this->membersList = membersList;
}
