#include "group.h"

Group::Group(QString groupname,QString groupImage)
{
    this->groupname = groupname;
    this->groupImage = groupImage;
}
