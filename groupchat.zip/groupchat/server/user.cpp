#include "user.h"

User::User(QString username, QString password, QString nickname, QString headImage,QString grouNameList)
{
    this->username = username;
    this->password = password;
    this->nickname = nickname;
    this->headImage = headImage;
    this->groupNameList = grouNameList;
}
