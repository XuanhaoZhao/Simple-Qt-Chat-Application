#ifndef USER_H
#define USER_H

#include <QString>
#include <vector>
class User
{
public:
    User(QString username = "", QString password = "", QString nickname = "",  QString headImage = "", QString groupName = "");
    QString username;
    QString password;
    QString nickname;

    QString headImage;
    QString groupNameList;
};

#endif // USER_H
