#ifndef GROUP_H
#define GROUP_H
#include<QString>
#include<vector>
class Group
{

    Group(QString groupname = "", QString groupImage = "");
    QString groupname;

    QString groupImage;
    std::vector<QString> usersInGroup;
};

#endif // GROUP_H
