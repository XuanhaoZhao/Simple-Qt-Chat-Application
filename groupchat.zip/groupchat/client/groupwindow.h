#ifndef GroupWindow_H
#define GroupWindow_H

#include <QMainWindow>
#include <QCloseEvent>
#include <QMimeData>
#include <QImageReader>
#include <QFileDialog>
#include <QMessageBox>
#include "group.h"
#include "protocol.h"
#include "record.h"
#include "group.h"
namespace Ui {
class GroupWindow;
}

class GroupWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit GroupWindow(QWidget *parent = 0);
    ~GroupWindow();
    void setProtocol(Protocol *protocol);
    void setOthers(bool isGroup, QString groupname);

public:
    void setSendBtnMenu();
    void onEnterAction();
    void onEnterCtrlAction();

private slots:
    void on_exitButton_clicked();
    void on_sendButton_clicked();
    void needRefreshMessage();

    void on_sendPicture_clicked();
    void getGroupUsers(QJsonArray);
    void on_sendFile_clicked();
    void on_screen_clicked();
    void sendScreenPicture();
    void textEdit_pic(QString);

protected:
    bool eventFilter(QObject *target, QEvent *event);
//    void dragEnterEvent(QDragEnterEvent *e);
//    void dropEvent(QDropEvent *e);

private:
    Ui::GroupWindow *ui;
    Protocol *protocol = nullptr;
    Record record;


    bool controlPressed = false;
    Group itGroup;
    bool isGroup = true;
    void refreshMessage();
    void closeEvent(QCloseEvent *event);

    QAction *m_sendAction,  *m_ctrlSendAction;
};

#endif // GroupWindow_H
