#include "signupwindow.h"
#include "ui_signupwindow.h"

SignUpWindow::SignUpWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::SignUpWindow) {
    ui->setupUi(this);
    this->setWindowFlags(this->windowFlags() &~ Qt::WindowMaximizeButtonHint);

    this->setWindowTitle("NeuTalk - Sign Up");
    ui->label->setFont(QFont("Helvetica", 16));
    ui->label_2->setFont(QFont("Helvetica", 16));
    ui->label_3->setFont(QFont("Helvetica", 16));
    ui->nickname->setFont(QFont("Helvetica", 16));
    ui->username->setFont(QFont("Helvetica", 16));
    ui->password->setFont(QFont("Helvetica", 16));
    ui->label_5->setFont(QFont("Helvetica", 16));
    ui->check_psw->setFont(QFont("Helvetica", 16));
    ui->signUp->setFont(QFont("Helvetica", 12));
    ui->addFace->setFont(QFont("Helvetica", 12));

    ui->username->setPlaceholderText("Unique Name...");
    ui->password->setPlaceholderText("...");
    ui->check_psw->setPlaceholderText("Check ...");
    ui->nickname->setPlaceholderText("Any Name...");
}

SignUpWindow::~SignUpWindow() {
    delete ui;
}

void SignUpWindow::setProtocol(Protocol *protocol) {
    this->protocol = protocol;
    connect(protocol, &Protocol::signUpSuccess, this, &SignUpWindow::signUpSuccess);
    connect(protocol, &Protocol::signUpFailed, this, &SignUpWindow::signUpFailed);
//    connect(ui->nickname, &QLineEdit::returnPressed, this, &SignUpWindow::on_signUp_clicked);
}

void SignUpWindow::on_signUp_clicked() {
    if(ui->username->text() != "" && ui->password->text() != "" && ui->check_psw->text() != "" && ui->nickname->text() != "") {
        QString reg = "^(?![\\d]+$)(?![a-zA-Z]+$)(?![^\\da-zA-Z]+$).{8,16}$";
        QRegExp rx(reg);
        QString psw = ui->password->text();
        bool ok = rx.exactMatch(psw);
        if (ok) {
            if (ui->check_psw->text() == ui->password->text()) {
                QFile headfile("://assets/Lock.jpg");
                headfile.open(QFile::ReadOnly);
                QString defaultHeadImage =(QString)(headfile.readAll().toBase64());
                qDebug() << "Default headImage Sending ... " << defaultHeadImage.length();
                protocol->sendSignUp(ui->username->text(), ui->password->text(), ui->nickname->text(), defaultHeadImage);
                headfile.close();
            }
            else {
                QMessageBox::critical(NULL, "NeuTalk", "Passwords Are Not Consistent!");
            }
        }
        else {
            QMessageBox::critical(NULL, "NeuTalk", "Invalid Password! \n Require 8~16 characters and AT LEAST two different kinds among Numbers, Letters and Symbols.");
        }
    } else {
        QMessageBox::critical(NULL, "NeuTalk", "Please input username, passwords and nickname!");
    }
}

void SignUpWindow::signUpSuccess() {
    QMessageBox::information(NULL, "NeuTalk", "Sign Up Success! Please turn back and sign in!");
    ui->username->setText("");
    ui->password->setText("");
    ui->nickname->setText("");
    this->close();
}

void SignUpWindow::signUpFailed() {
    QMessageBox::critical(NULL, "NeuTalk", "Sign Up Failed! Invalid Username!");
}

void SignUpWindow::on_addFace_clicked() {
    if(!faceSignUpWinodw) {
        faceSignUpWinodw = new FaceSignUpWindow(this);
    }
    faceSignUpWinodw->initCamera();
    faceSignUpWinodw->show();
}
