#include "user.h"

User::User(QString username, QString password, QString nickname, QString groupsname, QString headImage) {
    this->username = username;
    this->password = password;
    this->nickname = nickname;
    this->groupsname = groupsname;
    this->headImage = headImage;
}
