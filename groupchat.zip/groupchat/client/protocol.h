#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <QWebSocket>
#include <QObject>
#include <QVariant>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

#include <vector>
#include <map>

#include "user.h"
#include "message.h"
#include "record.h"
#include "group.h"

class Protocol : public QObject {
    Q_OBJECT
public:
    Protocol();
    ~Protocol();
    User me;
    std::vector<QString> friendsUsername;
    std::map<QString, QString> friendsNickname;
    std::map<QString, QString> friendsHeadImage;
    std::map<QString, int> friendsNewMessage;
    std::map<QString, int> groupNewMessage;
    QString openWindowWith;
    std::vector<QString> openGroupWindowWith;
    std::vector<QString> groupsName;

    bool connectServer(QString ws);
    bool sendSignIn(QString username, QString password);
    bool sendSignUp(QString, QString, QString, QString);
    bool sendGetFriendsList();
    bool sendGetGroupsList();
    bool sendFriendMessage(Message message);
    bool sendFaceSignIn(QString face_base64);
    bool sendGetFriendsHeadImage();
    bool sendGetGroupUsers(QString groupname);

private:
    QWebSocket *socket;
    QString token;
    Record record;

    void router(QString data); // router
    void recvSignIn(QString data); // package 01
    void recvSignUp(QString data); // package 02
    void recvGetFriendsList(QString data);
    void recvGetGroupsList(QString data);// package 03
    void recvFriendMessage(QString data); // package 08
    void recvGetFriendsHeadImage(QString data);
    void recvGetGroupsHeadImage(QString data);
    void recvGetGroupUsers(QString data);


signals:
    // signIn
    void signInSuccess();
    void signInFailed();

    // signUp
    void signUpSuccess();
    void signUpFailed();

    // getFriendsList
    void getFriendsListSuccess();
    void getGroupsListSuccess();
    void getGroupUsers(QJsonArray);

    // refresh for TalkWindow
    void needRefreshMessage();

    // refresh for MainWindow
    void needRefreshFriendsList();
    void proimage_change(QString);
    void getFriendsHeadImageSuccess();

private slots:
    void onConnected();
    void onTextMessageReceived(QString data);

public slots:
    void image_change(QString head2);
};

#endif // PROTOCOL_H
