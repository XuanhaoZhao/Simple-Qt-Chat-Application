#include "head_label.h"
#include<QFile>
head_label::head_label(QWidget *parent) : QLabel(parent)
{

}
void head_label:: mouseReleaseEvent(QMouseEvent *ev)
{
    if(ev->button() ==Qt::LeftButton)
    {
        QString filename = QFileDialog::getOpenFileName(this,"请选择替换的头像图片","./");
        emit image_change(filename);
    }
}
