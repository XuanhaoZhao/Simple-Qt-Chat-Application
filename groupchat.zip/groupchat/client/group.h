#ifndef GROUP_H
#define GROUP_H
#include<QString>
#include<vector>
#include<user.h>
class Group
{
public:
    Group(QString groupname = "", QString groupImage = "");
    QString groupname;

    QString groupImage;
    std::vector<QString> usersInGroup;
};

#endif // GROUP_H
