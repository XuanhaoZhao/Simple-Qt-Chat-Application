#ifndef USER_H
#define USER_H

#include <QString>

class User {
public:
    User(QString username = "", QString password = "", QString nickname = "", QString groupsname = "", QString headImage = "");
    QString username;
    QString password;
    QString nickname;
    QString groupsname;
    QString headImage;
};

#endif // USER_H
