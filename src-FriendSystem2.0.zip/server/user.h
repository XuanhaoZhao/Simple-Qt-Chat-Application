#ifndef USER_H
#define USER_H

#include <QString>

class User
{
public:
    User(QString username = "", QString password = "", QString nickname = "", QString groupslist = "[]", QString headImage = "", QString friendsList = "");
    QString username;
    QString password;
    QString nickname;
    QString groupslist;
    QString headImage;
    QString friendsList;
};

#endif // USER_H
