#ifndef REQUESTVALIDATIONWINDOW_H
#define REQUESTVALIDATIONWINDOW_H

#include <QMainWindow>
#include "protocol.h"
#include "record.h"

namespace Ui {
class RequestValidationWindow;
}

class RequestValidationWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit RequestValidationWindow(QWidget *parent = nullptr);
    void setProtocol (Protocol *protocol);
    ~RequestValidationWindow();


public slots:
    void RequestValidated();
    void RefreshAddFriendRequestList();

signals:
    void validationCommitted();

private:
    Ui::RequestValidationWindow *ui;
    Protocol *protocol;
    Record record;
};

#endif // REQUESTVALIDATIONWINDOW_H
