#ifndef HEAD_LABEL_H
#define HEAD_LABEL_H

#include<QMouseEvent>
#include<QLabel>
#include<QFileDialog>
class head_label : public QLabel
{
    Q_OBJECT
public:
    explicit head_label(QWidget *parent = nullptr);


    void mouseReleaseEvent(QMouseEvent *ev) override;


signals:
   void image_change(QString filename);

};

#endif // HEAD_LABEL_H
