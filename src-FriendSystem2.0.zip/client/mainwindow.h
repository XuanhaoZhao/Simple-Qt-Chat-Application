#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>

#include "talkwindow.h"
#include "protocol.h"
#include "chatwindow.h"
#include "addfriendwindow.h"
#include "requestvalidationwindow.h"
#include "user.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void setProtocol(Protocol *protocol);
    void refreshFriendsList();


private slots:
    void getFriendsListSuccess();
    void friendClicked();
    void getFriendsHeadImageSuccess();
    void windowchange(QString);
    void on_addFriend_clicked();
    void on_validation_clicked();

private:
    Ui::MainWindow *ui;
    Protocol *protocol = nullptr;
    TalkWindow *talkWindow = nullptr;
    AddFriendWindow *addFriendWindow = nullptr;
    RequestValidationWindow *requestValidationWindow = nullptr;

signals:
    void recvFriendsListSuccess();
};

#endif // MAINWINDOW_H
