#include "requestvalidationwindow.h"
#include "ui_requestvalidationwindow.h"

#include <QPushButton>

RequestValidationWindow::RequestValidationWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RequestValidationWindow)
{
    ui->setupUi(this);
}

void RequestValidationWindow::setProtocol(Protocol *protocol)
{
    this->protocol = protocol;
    connect(this->protocol, &Protocol::needRefreshAddFriendRequestList, this, &RequestValidationWindow::RefreshAddFriendRequestList);
    connect(this->protocol, &Protocol::validationCommitted, this, &RequestValidationWindow::RefreshAddFriendRequestList);
    this->RefreshAddFriendRequestList();
}

RequestValidationWindow::~RequestValidationWindow()
{
    delete ui;
}

void RequestValidationWindow::RefreshAddFriendRequestList()
{
qDebug() << "Conduct RefreshAddFriendRequestList";
    QWidget *widget = ui->list->widget(0);
    if(widget->layout()) {
        delete widget->layout();
    }
    QVBoxLayout *layout = new QVBoxLayout();

    std::vector<Message> requests = record.selectAddFriendRecordByUsername(protocol->me.username);
qDebug() << "Request Size : " << requests.size();

    for (std::vector<Message>::iterator it = requests.begin(); it != requests.end(); ++ it)
    {
        QString src = it->src;
        QPushButton *button = new QPushButton(src);
        button->setProperty("username", it->src);

        layout->addWidget(button, 0, Qt::AlignTop);
        connect(button, SIGNAL(clicked()), this, SLOT(RequestValidated()));
//        connect(button, SIGNAL(clicked), button, SLOT(close()));
    }

    layout->addStretch(50);
    widget->setLayout(layout);
}

void RequestValidationWindow::RequestValidated()
{
qDebug() << "Sending RequestValidated : " << sender()->property("username").toString();
    this->protocol->sendConnectFriends(sender()->property("username").toString());
}
