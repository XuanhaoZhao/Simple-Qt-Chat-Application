#include "chatwindow.h"
#include "ui_chatwindow.h"

#include <QSplitter>
#include <QObject>
#include <QTextEdit>

chatWindow::chatWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chatWindow)
{
    ui->setupUi(this);
    QSplitter *splitter = new QSplitter(Qt::Vertical, this);
    QTextEdit *textBottom = new QTextEdit(QObject::tr ("Bottom"), splitter);
    QTextEdit *textTop = new QTextEdit(QObject::tr ("Top"), splitter);
}

chatWindow::~chatWindow()
{
    delete ui;
}
