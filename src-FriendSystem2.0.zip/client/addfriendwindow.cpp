#include "addfriendwindow.h"
#include "ui_addfriendwindow.h"

AddFriendWindow::AddFriendWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AddFriendWindow)
{
    ui->setupUi(this);
    ui->addFriend->setText("Search & Add");
    ui->addFriend->resize(100, 50);
}

void AddFriendWindow::setProtocol(Protocol *protocol)
{
    this->protocol = protocol;
}

AddFriendWindow::~AddFriendWindow()
{
    delete ui;
}

void AddFriendWindow::on_addFriend_clicked()
{
    QString target = ui->lineEdit->text();
    this->protocol->sendAddFriendRequest(target);
}
