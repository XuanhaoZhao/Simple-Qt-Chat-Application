#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include<QByteArray>
#include"head_label.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    this->setWindowFlags(this->windowFlags() &~ Qt::WindowMaximizeButtonHint);
}

void MainWindow::setProtocol(Protocol *protocol) {
    this->protocol = protocol;

    ui->addFriend->setText("Add A Friend");
    ui->addFriend->resize(100, 50);

    ui->validation->setText("Validation");
    ui->validation->resize(100, 50);

    QByteArray str = this->protocol->me.headImage.toUtf8();
qDebug()<<"Receiving Head Image ..."  << this->protocol->me.headImage.size();
    QByteArray imgData = QByteArray::fromBase64(str);//字符串转图像数据
    QPixmap pixmap;
    pixmap.loadFromData(imgData);//从数据载入图像
    ui->label_head->setPixmap(pixmap);
    ui->label_head->setScaledContents(true);

    connect(this->protocol, SIGNAL(getFriendsListSuccess()), this, SLOT(getFriendsListSuccess()));
    connect(this->protocol, SIGNAL(needRefreshFriendsList()), this, SLOT(getFriendsListSuccess()));
    connect(ui->label_head, SIGNAL(image_change(QString)), this->protocol, SLOT(image_change(QString)));
    connect(this->protocol,SIGNAL(proimage_change(QString)),this,SLOT(windowchange(QString)));
    connect(this->protocol, &Protocol::getFriendsHeadImageSuccess, this, &MainWindow::getFriendsHeadImageSuccess);
    connect(this, &MainWindow::recvFriendsListSuccess, this->protocol, &Protocol::sendGetFriendsHeadImage);
    this->protocol->sendGetFriendsList();


}
void MainWindow::windowchange(QString)
{
    QByteArray str = this->protocol->me.headImage.toUtf8();
qDebug()<< this->protocol->me.headImage.size();
    QByteArray imgData = QByteArray::fromBase64(str);//字符串转图像数据
    QPixmap pixmap;
    pixmap.loadFromData(imgData);//从数据载入图像
    ui->label_head->setPixmap(pixmap);
    ui->label_head->setScaledContents(true);
}

void MainWindow::on_addFriend_clicked()
{
    if (!addFriendWindow) {
        addFriendWindow = new AddFriendWindow(this);
        addFriendWindow->setProtocol(protocol);
    }
    addFriendWindow->show();
}

void MainWindow::on_validation_clicked()
{
    if (!requestValidationWindow) {
        requestValidationWindow = new RequestValidationWindow (this);
        requestValidationWindow->setProtocol(protocol);
    }
    requestValidationWindow->show();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::refreshFriendsList() {
        QWidget *widget = ui->list->widget(0);
        if(widget->layout()) {
            delete widget->layout();
        }
        QVBoxLayout *layout = new QVBoxLayout();

        for(std::vector<QString>::iterator it = protocol->friendsUsername.begin(); it != protocol->friendsUsername.end(); ++it) {
            QString format;
            if(protocol->friendsNewMessage[*it] > 0) {
                format = QString("%1 (%2)").arg(*it).arg(protocol->friendsNewMessage[*it]);
            } else {
                format = QString("%1").arg(*it);
            }
            QPushButton *button = new QPushButton(format);
            button->setProperty("username", *it);
            button->setProperty("nickname", protocol->friendsNickname[*it]);
            button->setProperty("headImage", protocol->friendsHeadImage[*it]);
            layout->addWidget(button, 0, Qt::AlignTop);
            connect(button, SIGNAL(clicked(bool)), this, SLOT(friendClicked()));
        }
        layout->addStretch(50);
        widget->setLayout(layout);
}

void MainWindow::getFriendsListSuccess() {
    emit recvFriendsListSuccess();
}

void MainWindow::friendClicked() {
    if(!talkWindow) {
        talkWindow = new TalkWindow(this);
        talkWindow->setProtocol(protocol);
    }
    protocol->openWindowWith = sender()->property("username").toString();
    protocol->friendsNewMessage[sender()->property("username").toString()] = 0;
    this->refreshFriendsList();
    talkWindow->setOthers(false, sender()->property("username").toString(), sender()->property("nickname").toString(), sender()->property("headImage").toString());
    talkWindow->show();
}

void MainWindow::getFriendsHeadImageSuccess()
{
    qDebug() << "Main " << "getFriendsHeadImageSuccess";
//    for(std::vector<QString>::iterator it = protocol->friendsUsername.begin(); it != protocol->friendsUsername.end(); ++it)
//    {
//        QString headImage = protocol->friendsHeadImage[*it];
//        qDebug() << "Head Image from " << *it << " : " <<headImage.size();
//        QByteArray byte_array1 = QByteArray::fromBase64(headImage.toLocal8Bit());
//        qDebug() << byte_array1.length();
//        QPixmap pix;
//        pix.loadFromData(byte_array1, "JPG");
//        QPixmap pix_scaled = pix.scaled(512, 512 ,Qt::KeepAspectRatio);
//        ui->label->resize(600, 600);
//        ui->label->setPixmap(pix);
//        qDebug() << pix.size();
//    }
    this->refreshFriendsList();
}
