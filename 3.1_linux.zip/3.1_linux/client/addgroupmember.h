#ifndef ADDGROUPMEMBER_H
#define ADDGROUPMEMBER_H

#include <QMainWindow>
#include "protocol.h"

namespace Ui {
class AddGroupMember;
}

class AddGroupMember : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddGroupMember(QWidget *parent = nullptr);
    void setProtocol (Protocol *, QString);
    ~AddGroupMember();

public slots:
    void on_addMember_clicked();
    void addGroupMemberRequestResult(QString);
    void addFailed_GroupExists();

private:
    Ui::AddGroupMember *ui;
    Protocol *protocol;
    QString groupname;
};

#endif // ADDGROUPMEMBER_H
