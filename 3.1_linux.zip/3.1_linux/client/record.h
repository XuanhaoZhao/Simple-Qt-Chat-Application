#ifndef RECORD_H
#define RECORD_H

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>

#include <vector>

#include "message.h"

class Record {
public:
    Record();
    ~Record();
    std::vector<Message> selectRecordByUsername(QString myName, QString username);
    std::vector<Message> selectRecordByGroupname(QString);
    std::vector<Message> selectAddFriendRecordByUsername(QString target);
    std::vector<Message> selectAddGroupMemberRecordByUsername(QString target);

    bool insertRecordByUsername(QString myName, QString username, Message message);
    bool insertAddFriendRecordByUsername(QString target, Message message);
    bool insertAddGroupMemberRecordByUsername(QString target, Message message);
    bool deleteAddFriendRequestRecord(QString, QString);
    bool deleteAddGroupMemberRequestRecord(QString, QString);
    bool insertRecordByGroupName(QString ,Message);

private:
    QSqlDatabase db;
    bool createTableIfNotExists(QString myName, QString username);
    bool createAddFriendTableIfNotExists(QString target);
    bool createGroupTableIfNotExists(QString);
    bool createGroupMemberTableIfNotExists(QString);
};

#endif // RECORD_H
