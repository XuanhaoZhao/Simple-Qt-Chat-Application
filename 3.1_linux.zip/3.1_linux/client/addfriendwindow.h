#ifndef ADDFRIENDWINDOW_H
#define ADDFRIENDWINDOW_H

#include <QMainWindow>
#include "protocol.h"

namespace Ui {
class AddFriendWindow;
}

class AddFriendWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddFriendWindow(QWidget *parent = nullptr);
    void setProtocol(Protocol *protocol);
    ~AddFriendWindow();

public slots:
    void on_addFriend_clicked();
    void addFailed_FriendExists();
    void addFriendRequestResult(QString);

private:
    Ui::AddFriendWindow *ui;
    Protocol *protocol;
};

#endif // ADDFRIENDWINDOW_H
