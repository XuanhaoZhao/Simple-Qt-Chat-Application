-- SQLite
INSERT INTO `groups` (groupname, creator, groupimage, memberslist)
VALUES ("ccc", "123", "", "123,456");