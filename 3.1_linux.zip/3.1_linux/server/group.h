#ifndef GROUP_H
#define GROUP_H
#include<QString>
#include<vector>
class Group
{
public:
    Group(QString groupName = "", QString creator = "", QString groupImage = "", QString membersList = "");
    QString groupName;
    QString creator;
    QString groupImage;
    QString membersList;
};

#endif // GROUP_H
