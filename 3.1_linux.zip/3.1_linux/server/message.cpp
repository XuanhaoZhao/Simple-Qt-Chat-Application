#include "message.h"

Message::Message() {

}
