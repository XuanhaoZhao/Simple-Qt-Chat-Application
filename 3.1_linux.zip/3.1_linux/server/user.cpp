#include "user.h"

User::User(QString username, QString password, QString nickname, QString groupsList, QString headImage, QString friendsList)
{
    this->username = username;
    this->password = password;
    this->nickname = nickname;
    this->groupsList = groupsList;
    this->headImage = headImage;
    this->friendsList = friendsList;
}
