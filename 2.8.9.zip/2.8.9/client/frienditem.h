#ifndef FRIENDITEM_H
#define FRIENDITEM_H

#include <QWidget>
#include "protocol.h"
#include <QPushButton>

namespace Ui {
class Frienditem;
}

class Frienditem : public QWidget
{
    Q_OBJECT

public:
    explicit Frienditem(QWidget *parent = nullptr,QString Username="",Protocol * protocol=nullptr);
    QPushButton * getButton();
    ~Frienditem();

private:
    Ui::Frienditem *ui;
};

#endif // FRIENDITEM_H
