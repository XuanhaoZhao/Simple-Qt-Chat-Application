#include "head_label.h"
#include<QFile>
#include <QMessageBox>

head_label::head_label(QWidget *parent) : QLabel(parent)
{

}
void head_label:: mouseReleaseEvent(QMouseEvent *ev)
{
    if(ev->button() ==Qt::LeftButton)
    {
        QString path = QFileDialog::getOpenFileName(this,tr("Please choose the picture to replace head image"),".",tr("Image Files(*.jpg *.png)"));
        if(!path.isEmpty()){
            QImage* img = new QImage;
            if(!(img->load(path))) //加载图像
            {
               QMessageBox::information(this, tr("Open Picture Failed"), tr("Open Picture Failed!"));
               delete img;
               return;
            }
            delete img;
            emit image_change(path);
        }
    }
}
