#ifndef VALIDATIONWINDOW_H
#define VALIDATIONWINDOW_H

#include <QtWidgets/QWidget>
#include <QMainWindow>

namespace Ui {
class ValidationWindow;
}

class ValidationWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit ValidationWindow(QWidget *parent = nullptr);
    ~ValidationWindow();

private:
    Ui::ValidationWindow *ui;
};

#endif // VALIDATIONWINDOW_H
