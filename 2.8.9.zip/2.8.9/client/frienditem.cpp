#include "frienditem.h"
#include "ui_frienditem.h"
#include "protocol.h"
#include "mainwindow.h"

Frienditem::Frienditem(QWidget *parent, QString username,Protocol * protocol) :
    QWidget(parent),
    ui(new Ui::Frienditem)
{
    ui->setupUi(this);


    QByteArray str = protocol->me.headImage.toUtf8();
    QByteArray imgData = QByteArray::fromBase64(str);
    QPixmap pixmap;
    pixmap.loadFromData(imgData);
    ui->label->setPixmap(pixmap);
    ui->label->setScaledContents(true);
    ui->label->setScaledContents(true);

    ui->pushButton->setFont(QFont("Helvetica", 12));
    ui->pushButton->setText(username);
    ui->pushButton->adjustSize();
    ui->pushButton->setProperty("username",username);
    ui->pushButton->setProperty("nickname", protocol->friendsNickname[username]);
    ui->pushButton->setProperty("headImage", protocol->friendsHeadImage[username]);
}

QPushButton *Frienditem::getButton()
{
    return ui->pushButton;
}


Frienditem::~Frienditem()
{
    delete ui;
}
