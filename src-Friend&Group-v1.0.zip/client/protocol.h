#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <QWebSocket>
#include <QObject>
#include <QVariant>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>

#include <vector>
#include <map>

#include "user.h"
#include "message.h"
#include "record.h"

class Protocol : public QObject {
    Q_OBJECT
public:
    Protocol();
    ~Protocol();
    User me;
    std::vector<QString> friendsUsername;
    std::vector<QString> groupsName;
    std::map<QString, QString> friendsNickname;
    std::map<QString, QString> friendsHeadImage;
    std::map<QString, QString> groupsImage;
    std::map<QString, int> friendsNewMessage;
    std::map<QString, int> groupsNewMessage;
    QString openWindowWith;

    bool connectServer(QString ws);
    bool sendSignIn(QString username, QString password);
    bool sendSignUp(QString, QString, QString, QString);
    bool sendGetFriendsList();
    bool sendGetGroupsList();
    bool sendFriendMessage(Message message);
    bool sendFaceSignIn(QString face_base64);
    bool sendGetFriendsHeadImage();
    bool sendAddFriendRequest(QString);
    bool sendConnectFriends(QString);
    bool sendInviteMember(QString);
    bool sendShakeAction(QString, QString);
    bool sendCreateGroup(QString);
    bool denyAddFriendRequest(QString);
    bool denyAddGroupMemberRequest(QString);
    bool sendGetGroupUsers(QString);
    bool sendGroupMessage(Message);
    bool sendAddGroupMemberRequest(QString, QString);

private:
    QWebSocket *socket;
    QString token;
    Record record;

    void router(QString data); // router
    void recvSignIn(QString data); // package 01
    void recvSignUp(QString data); // package 02
    void recvGetFriendsList(QString data); // package 03
    void recvFriendMessage(QString data); // package 08
    void recvGetFriendsHeadImage(QString data);
    void recvAddFriendRequest (QString);
    void recvConnectFriends(QString);
    void deliverShakeAction(QString);
    void recvAddFriendRequestReply(QString);
    void recvAddGroupMemberRequestReply(QString);
    void recvCreateGroup(QString);
    void recvGetGroupUsers(QString);
    void recvGroupMessage(QString);
    void recvGetGroupsList(QString);
    void recvAddGroupMemberRequest(QString);
    void recvInviteMember(QString);

signals:
    // signIn
    void signInSuccess();
    void signInFailed();

    // signUp
    void signUpSuccess();
    void signUpFailed();

    // getFriendsList
    void getFriendsListSuccess();

    // refresh for TalkWindow
    void needRefreshMessage();

    // refresh for MainWindow
    void needRefreshFriendsList();
    void proimage_change(QString);
    void getFriendsHeadImageSuccess();

    void needRefreshAddFriendRequestList();
    void needRefreshGroupMessage();
    void validationCommitted();
    void needRefreshGroupsList();
    void duplicatedFriends();
    void creatGroupSuccess();
    void needShakeAction (QString);
    void addFriendRequestResult (QString);
    void addGroupMemberRequestResult(QString);
    void getGroupUsersSucess(QString);
    void getGroupsListSuccess();
    void duplicatedGroups();
    void needRefreshAddGroupMemberRequestList();

//    void needRegetFriendsList();
private slots:
    void onConnected();
    void onTextMessageReceived(QString data);

public slots:
    void image_change(QString head2);
};

#endif // PROTOCOL_H
