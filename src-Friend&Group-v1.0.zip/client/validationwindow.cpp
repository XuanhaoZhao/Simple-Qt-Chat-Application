#include "validationwindow.h"
#include "ui_validationwindow.h"
#include <QListWidgetItem>
#include "listitem.h"

ValidationWindow::ValidationWindow(QWidget *parent)
    : QMainWindow(parent)
{
    ui->setupUi(this);

    //ui->listWidget->setAlternatingRowColors(true);

    QListWidgetItem *item1 = new QListWidgetItem(ui->listWidget);
    item1->setSizeHint(QSize(100, 60));
    ListItem *list1 = new ListItem(ui->listWidget);
    ui->listWidget->addItem(item1);
    ui->listWidget->setItemWidget(item1, list1);


    QListWidgetItem *item2 = new QListWidgetItem(ui->listWidget);
    item2->setSizeHint(QSize(100, 60));
    ListItem *list2 = new ListItem(ui->listWidget);
    ui->listWidget->addItem(item2);
    ui->listWidget->setItemWidget(item2, list2);

    QListWidgetItem *item3 = new QListWidgetItem(ui->listWidget);
    item3->setSizeHint(QSize(100, 60));
    ListItem *list3 = new ListItem(ui->listWidget);
    ui->listWidget->addItem(item3);
    ui->listWidget->setItemWidget(item3, list3);

    QListWidgetItem *item4 = new QListWidgetItem(ui->listWidget);
    item4->setSizeHint(QSize(100, 60));
    ListItem *list4 = new ListItem(ui->listWidget);
    ui->listWidget->addItem(item4);
    ui->listWidget->setItemWidget(item4, list4);

    //ui->listWidget->setStyleSheet("QListWidget#listWidget{alternate-background-color:blue;background:yellow}");

    //ui->listWidget->addItem(QString("ÕÅÈý"));
    //ui->listWidget->addItem(QString("ÀîËÄ"));
    //ui->listWidget->addItem(QString("Íõ¶þ"));
}
