#include "addgroupmember.h"
#include "ui_addgroupmember.h"

#include <QMessageBox>

AddGroupMember::AddGroupMember(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AddGroupMember)
{
    ui->setupUi(this);
}

void AddGroupMember::setProtocol(Protocol *protocol, QString groupname)
{
    this->protocol = protocol;
    this->groupname = groupname;
    connect(this->protocol, &Protocol::duplicatedGroups, this, &AddGroupMember::addFailed_GroupExists);
    connect(this->protocol, SIGNAL(addGroupMemberRequestResult(QString)), this, SLOT(addGroupMemberRequestResult(QString)));
}

AddGroupMember::~AddGroupMember()
{
    delete ui;
}

void AddGroupMember::on_addMember_clicked()
{
    QString target = ui->lineEdit->text();
    this->protocol->sendAddGroupMemberRequest(target, this->groupname);
}

void AddGroupMember::addFailed_GroupExists()
{
    QMessageBox::critical(NULL, "NeuTalk", "Add Failed! You have been in the group already!");
}

void AddGroupMember::addGroupMemberRequestResult(QString result)
{
    if (result == "success") {
        QMessageBox::information(NULL, "NeuTalk", "Add Request Sent Successfully!");
    } else {
        QMessageBox::critical(NULL, "NeuTalk", "Add Failed! Group Not Found");
    }
}
