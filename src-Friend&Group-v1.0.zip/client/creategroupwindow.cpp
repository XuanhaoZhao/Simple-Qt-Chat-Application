#include "creategroupwindow.h"
#include "ui_creategroupwindow.h"

CreateGroupWindow::CreateGroupWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateGroupWindow)
{
    ui->setupUi(this);
}

void CreateGroupWindow::setProtocol(Protocol * protocol){
    this->protocol = protocol;
    connect(ui->Confirm,&QPushButton::clicked, this,&CreateGroupWindow::pushButtonConfirm);
}
CreateGroupWindow::~CreateGroupWindow()
{
    delete ui;
}

void CreateGroupWindow::pushButtonConfirm()
{

    QString groupname = ui->groupname->toPlainText();
    this->protocol->sendCreateGroup(groupname);
    connect(this->protocol,&Protocol::creatGroupSuccess,this,[=](){
        this->close();
    });

}

