#include "groupwindow.h"
#include "ui_groupwindow.h"
#include "screenshot.h"

#include <QTextCodec>
#include <QPropertyAnimation>

GroupWindow::GroupWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::GroupWindow) {
    ui->setupUi(this);
    ui->sendArea->installEventFilter(this);

    ui->invite->setText("Invite");
    ui->invite->setFont(QFont("Helvetica", 10));


    ui->exitButton->setFont(QFont("Helvetica", 10));
    ui->sendButton->setFont(QFont("Helvetica", 10));
    ui->exitButton->resize(75, 35);
    ui->sendButton->resize(75, 35);
    ui->pushButton->resize(10, 35);

    setSendBtnMenu();

    QPixmap file_icon("://assets/file2.png");
    QPixmap file_pix = file_icon.scaled(ui->sendFile->size(),Qt::KeepAspectRatio);
    ui->sendFile->setIcon(file_pix);
    ui->sendFile->setStyleSheet("border: 0px");

    QPixmap pic_icon("://assets/photo.png");
    QPixmap pic_pix = pic_icon.scaled(ui->sendPicture->size(),Qt::KeepAspectRatio);
    ui->sendPicture->setIcon(pic_pix);
    ui->sendPicture->setStyleSheet("border: 0px");

    QPixmap screen_icon("://assets/screen.png");
    QPixmap screen_pix = screen_icon.scaled(ui->sendPicture->size(),Qt::KeepAspectRatio);
    ui->screen->setIcon(screen_pix);
    ui->screen->setStyleSheet("border: 0px");

    QPixmap shake_icon("://assets/shake.png");
    QPixmap shake_pix = shake_icon.scaled(ui->sendPicture->size(),Qt::KeepAspectRatio);
    ui->shake->setIcon(shake_pix);
    ui->shake->setStyleSheet("border: 0px");


//    ui->sendArea->setAcceptDrops(false);
//    this->setAcceptDrops(true);
}

void GroupWindow::setSendBtnMenu()
{
    QMenu* menu = new QMenu(this);
    menu->setWindowFlags(menu->windowFlags() | Qt::FramelessWindowHint);
    menu->setAttribute(Qt::WA_TranslucentBackground);
    menu->setObjectName("sendMenu");
    m_sendAction = menu->addAction(QStringLiteral("Press Enter"), this, SLOT(onEnterAction()));
    m_ctrlSendAction = menu->addAction(QStringLiteral("Press Enter + Ctrl"), this, SLOT(onEnterCtrlAction()));

    QActionGroup* actiongroup = new QActionGroup(this);
    m_sendAction->setCheckable(true);
    m_ctrlSendAction->setCheckable(true);
    m_sendAction->setChecked(true);
    actiongroup->addAction(m_sendAction);
    actiongroup->addAction(m_ctrlSendAction);
    ui->pushButton->setMenu(menu);
}

void GroupWindow::onEnterAction()
{
    m_sendAction->setChecked(true);
    m_ctrlSendAction->setChecked(false);
}

void GroupWindow::onEnterCtrlAction()
{
    m_ctrlSendAction->setChecked(true);
    m_sendAction->setChecked(false);
}

void GroupWindow::getGroupUsers(QString memberslist)
{
qDebug() << "getGroupUsers : " << memberslist;
    QStringList membersList_strlist = memberslist.split(",");
}

void GroupWindow::on_invite_clicked()
{
    if (!addGroupMember) {
        addGroupMember = new AddGroupMember(this);
        addGroupMember->setProtocol(protocol, this->groupname);
    }
    addGroupMember->show();
}

GroupWindow::~GroupWindow() {
    delete ui;
}

void GroupWindow::setProtocol(Protocol *protocol) {
    this->protocol = protocol;
    connect(this->protocol, &Protocol::needRefreshMessage, this, &GroupWindow::needRefreshMessage);
    connect(this->protocol, SIGNAL(needShakeAction(QString)), this, SLOT(conductShakeAction(QString)));
}

void GroupWindow::refreshMessage() {
    // friend message
    ui->msgArea->setText("");
    std::vector<Message> message = record.selectRecordByGroupname(this->groupname);
    for(std::vector<Message>::iterator it = message.begin(); it != message.end(); ++it) {
        if(it->type == "plain") {
            QString format = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 \n </font>";
            ui->msgArea->append(format.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src)));
            ui->msgArea->append(it->text);
        } else if(it->type == "picture") {
            QString format = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 </font>";
            ui->msgArea->append(format.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src)));
            ui->msgArea->append("");
            textEdit_pic(it->text);

        } else if(it->type == "file") {
            QString fileMessage = it->text;
            QString fileName = fileMessage.split(",")[0];
            QByteArray fileValue = QByteArray::fromBase64(fileMessage.split(",")[1].toUtf8());
            QFile file(fileName);
            file.open(QFile::WriteOnly);
            QDataStream in(&file);
            in.writeRawData(fileValue, fileValue.size());
            file.close();
            QString format1 = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 </font>";
            QString format2 = "[File] has been saved as <font color = \"#FF0000\"> %1 </font>";
            ui->msgArea->append(format1.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src)));
            ui->msgArea->append(format2.arg(fileName));
        }
    }
    QTextCursor cursor = ui->msgArea->textCursor();
    cursor.movePosition(QTextCursor::End);
    ui->msgArea->setTextCursor(cursor);
}

void GroupWindow::needRefreshMessage() {
    this->refreshMessage();
}

void GroupWindow::conductShakeAction(QString source)
{
//qDebug() << source << " " << this->partnerUsername;
//    if (source == this->partnerUsername) {
//        QPropertyAnimation *pAnimation = new QPropertyAnimation(this, "pos");
//        pAnimation->setDuration(500);
//        pAnimation->setLoopCount(2);
//        pAnimation->setKeyValueAt(0, QPoint(geometry().x() - 3, geometry().y() - 3));
//        pAnimation->setKeyValueAt(0.1, QPoint(geometry().x() + 6, geometry().y() + 6));
//        pAnimation->setKeyValueAt(0.2, QPoint(geometry().x() - 6, geometry().y() + 6));
//        pAnimation->setKeyValueAt(0.3, QPoint(geometry().x() + 6, geometry().y() - 6));
//        pAnimation->setKeyValueAt(0.4, QPoint(geometry().x() - 6, geometry().y() - 6));
//        pAnimation->setKeyValueAt(0.5, QPoint(geometry().x() + 6, geometry().y() + 6));
//        pAnimation->setKeyValueAt(0.6, QPoint(geometry().x() - 6, geometry().y() + 6));
//        pAnimation->setKeyValueAt(0.7, QPoint(geometry().x() + 6, geometry().y() - 6));
//        pAnimation->setKeyValueAt(0.8, QPoint(geometry().x() - 6, geometry().y() - 6));
//        pAnimation->setKeyValueAt(0.9, QPoint(geometry().x() + 6, geometry().y() + 6));
//        pAnimation->setKeyValueAt(1, QPoint(geometry().x() - 3, geometry().y() - 3));
//        pAnimation->start(QAbstractAnimation::DeleteWhenStopped);
//    }
}

void GroupWindow::setOthers(bool isGroup, QString groupname, QString groupimage) {
    this->isGroup = isGroup;
    this->groupname = groupname;
    this->groupimage = groupimage;
    this->protocol->sendGetGroupUsers(groupname); //需不需要重写复制函数？
    connect(protocol,SIGNAL(getGroupUsersSucess(QString)),this, SLOT(getGroupUsers(QString)));
//    this->partnerNickname = partnerNickname;
//    this->partnerHeadImage = partnerHeadImage;

    this->setWindowTitle("Group Chat :" + this->groupname);
    if(!this->isGroup) {
        this->setFixedSize(780, this->height()); // friend is 780
    } else {
        this->setFixedSize(980, this->height()); // group is 980
    }
    //qDebug() << this->groupHeadImage.size();
    if (groupimage != "") {
        QByteArray bytes = QByteArray::fromBase64(this->groupimage.toLocal8Bit());
        qDebug() << bytes.length();
        QPixmap pix;
        pix.loadFromData(bytes);
        //QPixmap pix_scaled = pix.scaled(512, 512 ,Qt::KeepAspectRatio);
        ui->label->resize(50, 50);
        QPixmap pix_scaled = pix.scaled(ui->label->size(),Qt::KeepAspectRatio);
        ui->label->setPixmap(pix_scaled);
qDebug() << pix.size();
    }

    ui->label_2->setText(this->groupname);
    ui->label_2->setFont(QFont("Helvetica", 15));
//    ui->lineEdit->setText("He/She has nothing to say...");
    ui->lineEdit->setFont(QFont("Helvetica", 10));
    ui->lineEdit->adjustSize();
    refreshMessage();
}

void GroupWindow::on_exitButton_clicked() {
    this->close();
}

void GroupWindow::closeEvent(QCloseEvent *event) {
    ui->msgArea->setText("");
    ui->sendArea->setText("");
    protocol->openWindowWith = "";
    event->accept();
}

void GroupWindow::on_sendButton_clicked() {
    // friend message
    if(ui->sendArea->toPlainText() != "") {
        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->groupname;
        message.type = "plain";
        message.text = ui->sendArea->toPlainText();
        protocol->sendGroupMessage(message);
        record.insertRecordByGroupName(this->groupname, message);

        ui->sendArea->setText("");
        refreshMessage();
    } else {
        QMessageBox::critical(NULL, "NeuGroup", "Please input the message!");
    }
}

bool GroupWindow::eventFilter(QObject *target, QEvent *event) {
    if(target == ui->sendArea) {
        if(event->type() == QEvent::KeyPress) {
            QKeyEvent *key = static_cast<QKeyEvent *>(event);
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter) {
                if (this->m_sendAction->isChecked())
                {
                    if(this->controlPressed) {
                        ui->sendArea->append("");
                    } else {
                        on_sendButton_clicked();
                    }
                    return true;
                } else {
                    if(! this->controlPressed) {
                        ui->sendArea->append("");
                    } else {
                        on_sendButton_clicked();
                    }
                    return true;
                }

            } else if(key->key() == Qt::Key_Control) {
                this->controlPressed = true;
            }
        } else if(event->type() == QEvent::KeyRelease) {
            QKeyEvent *key = static_cast<QKeyEvent *>(event);
            if(key->key() == Qt::Key_Control) {
                this->controlPressed = false;
            }
        }
    }
    return QWidget::eventFilter(target,event);
}

void GroupWindow::textEdit_pic(QString text)
{
qDebug()<<"Enter textEdit_pic";
    QFile tmpFile("tmp.jpg");
    tmpFile.open(QIODevice::WriteOnly);

    QPixmap imagePixmap;
    imagePixmap.loadFromData(QByteArray::fromBase64(text.toUtf8()));
qDebug()<<text.toUtf8().data();
    QImage image = imagePixmap.toImage();
    bool is_stored = image.save(&tmpFile,"jpg");
qDebug() << "Save Picture Successfully"<<is_stored;
    tmpFile.close();
    QUrl tmpUrl(QUrl::fromLocalFile(tmpFile.fileName()));
qDebug()<<tmpUrl;
    QTextDocument *textDocument = ui->msgArea->document();
    textDocument->addResource(QTextDocument::ImageResource, QUrl(tmpUrl), QVariant(image));

    QTextCursor cursor = ui->msgArea->textCursor();
    QTextImageFormat imageFormat;

    imageFormat.setWidth(image.width()/(image.width()/150));
    imageFormat.setHeight(image.height()/(image.height()/150));
    imageFormat.setName(tmpUrl.toString());
    cursor.insertImage(imageFormat);
qDebug()<<"Show Done";
    tmpFile.remove();
}

//void GroupWindow::dragEnterEvent(QDragEnterEvent *e)
//{
//    if(e->mimeData()->hasFormat("text/uri-list")) {
//        e->acceptProposedAction();
//    } else {
//        e->ignore();
//    }
//}

//void GroupWindow::dropEvent(QDropEvent *e)
//{
//    QList<QUrl> urls = e->mimeData()->urls();
//    if(urls.empty())
//        return;
//    for (int i=0; i<urls.size(); i++) {
//        QString fileName = urls[i].toLocalFile();
//        QString extendName = fileName.right(4).toLower();
//        QUrl Uri(QString("file://%1").arg(fileName));
//        if(extendName.compare(".jpg")==0 || extendName.compare(".jpeg")==0 || extendName.compare(".png")==0 || extendName.compare(".bmp")==0 || extendName.compare(".gif")==0) {
//            QImage image = QImageReader(fileName).read();
//            QTextDocument * textDocument = ui->sendArea->document();
//            textDocument->addResource(QTextDocument::ImageResource, Uri, QVariant(image));
//            QTextCursor cursor = ui->sendArea->textCursor();
//            QTextImageFormat imageFormat;
//            int nSmall = image.width() / 150;
//            imageFormat.setWidth( image.width()/nSmall );
//            imageFormat.setHeight( image.height()/nSmall );
//            imageFormat.setName( Uri.toString() );
//            cursor.insertImage(imageFormat);
//            // qDebug() << fileName;
//        } else {
//            QImage image = QImageReader (":/picture/assets/file.png").read();
//            QTextDocument * textDocument = ui->sendArea->document();
//            textDocument->addResource(QTextDocument::ImageResource, Uri, QVariant(image));
//            QTextCursor cursor = ui->sendArea->textCursor();
//            QTextImageFormat imageFormat;
//            imageFormat.setWidth(image.width());
//            imageFormat.setHeight(image.height());
//            imageFormat.setName(Uri.toString());
//            cursor.insertImage(imageFormat);
//            // qDebug() << fileName;
//        }
//    }
//}

void GroupWindow::on_sendPicture_clicked() {
    QString arg = "";
    QString picturePath = QFileDialog::getOpenFileName(this, "Open File", "", "Images(*.png *.jpg *.jpeg *.bmp *.gif);", &arg);
    if(picturePath != "") {
        QFile file(picturePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->groupname;
        message.type = "picture";
        message.text = fileBase64;
        protocol->sendGroupMessage(message);
        record.insertRecordByGroupName(this->groupname, message);
        refreshMessage();
    }
}

void GroupWindow::on_shake_clicked()
{
    QPropertyAnimation *pAnimation = new QPropertyAnimation(this, "pos");
    pAnimation->setDuration(500);
    pAnimation->setLoopCount(2);
    pAnimation->setKeyValueAt(0, QPoint(geometry().x() - 3, geometry().y() - 3));
    pAnimation->setKeyValueAt(0.1, QPoint(geometry().x() + 6, geometry().y() + 6));
    pAnimation->setKeyValueAt(0.2, QPoint(geometry().x() - 6, geometry().y() + 6));
    pAnimation->setKeyValueAt(0.3, QPoint(geometry().x() + 6, geometry().y() - 6));
    pAnimation->setKeyValueAt(0.4, QPoint(geometry().x() - 6, geometry().y() - 6));
    pAnimation->setKeyValueAt(0.5, QPoint(geometry().x() + 6, geometry().y() + 6));
    pAnimation->setKeyValueAt(0.6, QPoint(geometry().x() - 6, geometry().y() + 6));
    pAnimation->setKeyValueAt(0.7, QPoint(geometry().x() + 6, geometry().y() - 6));
    pAnimation->setKeyValueAt(0.8, QPoint(geometry().x() - 6, geometry().y() - 6));
    pAnimation->setKeyValueAt(0.9, QPoint(geometry().x() + 6, geometry().y() + 6));
    pAnimation->setKeyValueAt(1, QPoint(geometry().x() - 3, geometry().y() - 3));
    pAnimation->start(QAbstractAnimation::DeleteWhenStopped);

//    protocol->sendShakeAction(protocol->me.username, this->partnerUsername);
}

void GroupWindow::on_sendFile_clicked() {
    QString arg = "";
    QString filePath = QFileDialog::getOpenFileName(this, "Open File", "", "All Files(*);", &arg);
    if(filePath != "") {
        QFile file(filePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());
        QString fileName = QFileInfo(filePath).fileName();

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->groupname;
        message.type = "file";
        message.text = fileName + "," + fileBase64;
        protocol->sendGroupMessage(message);
        record.insertRecordByGroupName(this->groupname, message);
        refreshMessage();
    }
}

void GroupWindow::on_screen_clicked()
{
    qDebug() << "Capturing...";
#if (QT_VERSION <= QT_VERSION_CHECK(5,0,0))
#if _MSC_VER
    QTextCodec *codec = QTextCodec::codecForName("gbk");
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
#endif
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);
    QTextCodec::setCodecForTr(codec);
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
    QTextCodec::setCodecForLocale(codec);
#endif
    ScreenWidget *scr = new ScreenWidget(nullptr);
    connect(scr, &ScreenWidget::sendScreenPicture, this, &GroupWindow::sendScreenPicture);
    scr->showFullScreen();

}

void GroupWindow::sendScreenPicture()
{
    QFile file("screen_tmp_path.txt");
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    QByteArray bytes = file.readAll();
    QString screenPath = QString::fromUtf8(bytes);
    qDebug() << screenPath;
    QString arg = "";
    QString picturePath = screenPath;
    if(picturePath != "") {
        QFile file(picturePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->groupname;
        message.type = "picture";
        message.text = fileBase64;
        protocol->sendGroupMessage(message);
        record.insertRecordByGroupName(this->groupname, message);
        refreshMessage();
    }
}
