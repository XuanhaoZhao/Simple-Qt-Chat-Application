#include "loadwindow.h"
#include "ui_loadwindow.h"

#include <QPainter>
#include <QPixmap>
#include <QLabel>
#include <QImage>

LoadWindow::LoadWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::LoadWindow) {
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
//    QLabel *label = new QLabel();
//    QImage image("D:/study/cs/QtProjects/jim-lite-main/assets/LoadWindow.png");
//    label->setPixmap(QPixmap::fromImage(image));
//    label->show();
}

LoadWindow::~LoadWindow() {
    delete ui;
}
