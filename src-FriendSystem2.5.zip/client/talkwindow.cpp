#include "talkwindow.h"
#include "ui_talkwindow.h"
#include "screenshot.h"

#include <QTextCodec>

TalkWindow::TalkWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::TalkWindow) {
    ui->setupUi(this);
    ui->sendArea->installEventFilter(this);

    ui->exitButton->setFont(QFont("Helvetica", 10));
    ui->sendButton->setFont(QFont("Helvetica", 10));
    ui->exitButton->resize(75, 35);
    ui->sendButton->resize(75, 35);
    ui->pushButton->resize(10, 35);

    setSendBtnMenu();

    QPixmap file_icon("://assets/file2.png");
    QPixmap file_pix = file_icon.scaled(ui->sendFile->size(),Qt::KeepAspectRatio);
    ui->sendFile->setIcon(file_pix);
    ui->sendFile->setStyleSheet("border: 0px");

    QPixmap pic_icon("://assets/photo.png");
    QPixmap pic_pix = pic_icon.scaled(ui->sendPicture->size(),Qt::KeepAspectRatio);
    ui->sendPicture->setIcon(pic_pix);
    ui->sendPicture->setStyleSheet("border: 0px");

    QPixmap screen_icon("://assets/screen.png");
    QPixmap screen_pix = screen_icon.scaled(ui->sendPicture->size(),Qt::KeepAspectRatio);
    ui->screen->setIcon(screen_pix);
    ui->screen->setStyleSheet("border: 0px");


//    ui->sendArea->setAcceptDrops(false);
//    this->setAcceptDrops(true);
}

void TalkWindow::setSendBtnMenu()
{
    QMenu* menu = new QMenu(this);
    menu->setWindowFlags(menu->windowFlags() | Qt::FramelessWindowHint);
    menu->setAttribute(Qt::WA_TranslucentBackground);
    menu->setObjectName("sendMenu");
    m_sendAction = menu->addAction(QStringLiteral("Press Enter"), this, SLOT(onEnterAction()));
    m_ctrlSendAction = menu->addAction(QStringLiteral("Press Enter + Ctrl"), this, SLOT(onEnterCtrlAction()));

    QActionGroup* actiongroup = new QActionGroup(this);
    m_sendAction->setCheckable(true);
    m_ctrlSendAction->setCheckable(true);
    m_sendAction->setChecked(true);
    actiongroup->addAction(m_sendAction);
    actiongroup->addAction(m_ctrlSendAction);
    ui->pushButton->setMenu(menu);
}

void TalkWindow::onEnterAction()
{
    m_sendAction->setChecked(true);
    m_ctrlSendAction->setChecked(false);
}

void TalkWindow::onEnterCtrlAction()
{
    m_ctrlSendAction->setChecked(true);
    m_sendAction->setChecked(false);
}

TalkWindow::~TalkWindow() {
    delete ui;
}

void TalkWindow::setProtocol(Protocol *protocol) {
    this->protocol = protocol;
    connect(this->protocol, &Protocol::needRefreshMessage, this, &TalkWindow::needRefreshMessage);
}

void TalkWindow::refreshMessage() {
    // friend message
    ui->msgArea->setText("");
    std::vector<Message> message = record.selectRecordByUsername(protocol->me.username, this->partnerUsername);
    for(std::vector<Message>::iterator it = message.begin(); it != message.end(); ++it) {
        if(it->type == "plain") {
            QString format = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 \n </font>";
            ui->msgArea->append(format.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src == protocol->me.username)?protocol->me.nickname:protocol->friendsNickname[it->src]));
            ui->msgArea->append(it->text);
        } else if(it->type == "picture") {
            QString format = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 </font>";
            ui->msgArea->append(format.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src == protocol->me.username)?protocol->me.nickname:protocol->friendsNickname[it->src]));
            ui->msgArea->append("");
            QPixmap imagePixmap;
            imagePixmap.loadFromData(QByteArray::fromBase64(it->text.toUtf8()));
            QImage image = imagePixmap.toImage();
            QTextDocument *textDocument = ui->msgArea->document();
            textDocument->addResource(QTextDocument::ImageResource, QUrl("[Picture]"), QVariant(image));
            QTextCursor cursor = ui->msgArea->textCursor();
            QTextImageFormat imageFormat;
            int nSmall = image.width() / 150;
            imageFormat.setWidth(image.width()/nSmall);
            imageFormat.setHeight(image.height()/nSmall);
            imageFormat.setName("[Picture]");
            cursor.insertImage(imageFormat);
        } else if(it->type == "file") {
            QString fileMessage = it->text;
            QString fileName = fileMessage.split(",")[0];
            QByteArray fileValue = QByteArray::fromBase64(fileMessage.split(",")[1].toUtf8());
            QFile file(fileName);
            file.open(QFile::WriteOnly);
            QDataStream in(&file);
            in.writeRawData(fileValue, fileValue.size());
            file.close();
            QString format1 = "<font color = \"#00FF00\">[%1]</font><font color = \"#0000FF\"> %2 </font>";
            QString format2 = "[File] has been saved as <font color = \"#FF0000\"> %1 </font>";
            ui->msgArea->append(format1.arg(it->time.toString("yyyy-MM-dd hh:mm:ss")).arg((it->src == protocol->me.username)?protocol->me.nickname:protocol->friendsNickname[it->src]));
            ui->msgArea->append(format2.arg(fileName));
        }
    }
    QTextCursor cursor = ui->msgArea->textCursor();
    cursor.movePosition(QTextCursor::End);
    ui->msgArea->setTextCursor(cursor);
}

void TalkWindow::needRefreshMessage() {
    this->refreshMessage();
}

void TalkWindow::setOthers(bool isGroup, QString partnerUsername, QString partnerNickname, QString partnerHeadImage) {
    this->isGroup = isGroup;
    this->partnerUsername = partnerUsername;
    this->partnerNickname = partnerNickname;
    this->partnerHeadImage = partnerHeadImage;
    this->setWindowTitle("Dialogue With " + this->partnerNickname);
    if(!this->isGroup) {
        this->setFixedSize(780, this->height()); // friend is 780
    } else {
        this->setFixedSize(980, this->height()); // group is 980
    }
    qDebug() << this->partnerHeadImage.size();
    QByteArray bytes = QByteArray::fromBase64(this->partnerHeadImage.toLocal8Bit());
    qDebug() << bytes.length();
    QPixmap pix;
    pix.loadFromData(bytes);
    //QPixmap pix_scaled = pix.scaled(512, 512 ,Qt::KeepAspectRatio);
    ui->label->resize(50, 50);
    QPixmap pix_scaled = pix.scaled(ui->label->size(),Qt::KeepAspectRatio);
    ui->label->setPixmap(pix_scaled);
    qDebug() << pix.size();
    ui->label_2->setText(this->partnerUsername);
    ui->label_2->setFont(QFont("Helvetica", 15));
    ui->lineEdit->setText("He/She has nothing to say...");
    ui->lineEdit->setFont(QFont("Helvetica", 10));
    ui->lineEdit->adjustSize();
    refreshMessage();
}

void TalkWindow::on_exitButton_clicked() {
    this->close();
}

void TalkWindow::closeEvent(QCloseEvent *event) {
    ui->msgArea->setText("");
    ui->sendArea->setText("");
    protocol->openWindowWith = "";
    event->accept();
}

void TalkWindow::on_sendButton_clicked() {
    // friend message
    if(ui->sendArea->toPlainText() != "") {
        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->partnerUsername;
        message.type = "plain";
        message.text = ui->sendArea->toPlainText();
        protocol->sendFriendMessage(message);
        record.insertRecordByUsername(protocol->me.username, this->partnerUsername, message);

        ui->sendArea->setText("");
        refreshMessage();
    } else {
        QMessageBox::critical(NULL, "NeuTalk", "Please input the message!");
    }
}

bool TalkWindow::eventFilter(QObject *target, QEvent *event) {
    if(target == ui->sendArea) {
        if(event->type() == QEvent::KeyPress) {
            QKeyEvent *key = static_cast<QKeyEvent *>(event);
            if(key->key() == Qt::Key_Return || key->key() == Qt::Key_Enter) {
                if (this->m_sendAction->isChecked())
                {
                    if(this->controlPressed) {
                        ui->sendArea->append("");
                    } else {
                        on_sendButton_clicked();
                    }
                    return true;
                } else {
                    if(! this->controlPressed) {
                        ui->sendArea->append("");
                    } else {
                        on_sendButton_clicked();
                    }
                    return true;
                }

            } else if(key->key() == Qt::Key_Control) {
                this->controlPressed = true;
            }
        } else if(event->type() == QEvent::KeyRelease) {
            QKeyEvent *key = static_cast<QKeyEvent *>(event);
            if(key->key() == Qt::Key_Control) {
                this->controlPressed = false;
            }
        }
    }
    return QWidget::eventFilter(target,event);
}

//void TalkWindow::dragEnterEvent(QDragEnterEvent *e)
//{
//    if(e->mimeData()->hasFormat("text/uri-list")) {
//        e->acceptProposedAction();
//    } else {
//        e->ignore();
//    }
//}

//void TalkWindow::dropEvent(QDropEvent *e)
//{
//    QList<QUrl> urls = e->mimeData()->urls();
//    if(urls.empty())
//        return;
//    for (int i=0; i<urls.size(); i++) {
//        QString fileName = urls[i].toLocalFile();
//        QString extendName = fileName.right(4).toLower();
//        QUrl Uri(QString("file://%1").arg(fileName));
//        if(extendName.compare(".jpg")==0 || extendName.compare(".jpeg")==0 || extendName.compare(".png")==0 || extendName.compare(".bmp")==0 || extendName.compare(".gif")==0) {
//            QImage image = QImageReader(fileName).read();
//            QTextDocument * textDocument = ui->sendArea->document();
//            textDocument->addResource(QTextDocument::ImageResource, Uri, QVariant(image));
//            QTextCursor cursor = ui->sendArea->textCursor();
//            QTextImageFormat imageFormat;
//            int nSmall = image.width() / 150;
//            imageFormat.setWidth( image.width()/nSmall );
//            imageFormat.setHeight( image.height()/nSmall );
//            imageFormat.setName( Uri.toString() );
//            cursor.insertImage(imageFormat);
//            // qDebug() << fileName;
//        } else {
//            QImage image = QImageReader (":/picture/assets/file.png").read();
//            QTextDocument * textDocument = ui->sendArea->document();
//            textDocument->addResource(QTextDocument::ImageResource, Uri, QVariant(image));
//            QTextCursor cursor = ui->sendArea->textCursor();
//            QTextImageFormat imageFormat;
//            imageFormat.setWidth(image.width());
//            imageFormat.setHeight(image.height());
//            imageFormat.setName(Uri.toString());
//            cursor.insertImage(imageFormat);
//            // qDebug() << fileName;
//        }
//    }
//}

void TalkWindow::on_sendPicture_clicked() {
    QString arg = "";
    QString picturePath = QFileDialog::getOpenFileName(this, "Open File", "", "Images(*.png *.jpg *.jpeg *.bmp *.gif);", &arg);
    if(picturePath != "") {
        QFile file(picturePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->partnerUsername;
        message.type = "picture";
        message.text = fileBase64;
        protocol->sendFriendMessage(message);
        record.insertRecordByUsername(protocol->me.username, this->partnerUsername, message);
        refreshMessage();
    }
}

void TalkWindow::on_sendFile_clicked() {
    QString arg = "";
    QString filePath = QFileDialog::getOpenFileName(this, "Open File", "", "All Files(*);", &arg);
    if(filePath != "") {
        QFile file(filePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());
        QString fileName = QFileInfo(filePath).fileName();

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->partnerUsername;
        message.type = "file";
        message.text = fileName + "," + fileBase64;
        protocol->sendFriendMessage(message);
        record.insertRecordByUsername(protocol->me.username, this->partnerUsername, message);
        refreshMessage();
    }
}

void TalkWindow::on_screen_clicked()
{
    qDebug() << "Capturing...";
#if (QT_VERSION <= QT_VERSION_CHECK(5,0,0))
#if _MSC_VER
    QTextCodec *codec = QTextCodec::codecForName("gbk");
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
#endif
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);
    QTextCodec::setCodecForTr(codec);
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
    QTextCodec::setCodecForLocale(codec);
#endif
    ScreenWidget *scr = new ScreenWidget(nullptr);
    connect(scr, &ScreenWidget::sendScreenPicture, this, &TalkWindow::sendScreenPicture);
    scr->showFullScreen();

}

void TalkWindow::sendScreenPicture()
{
    QFile file("screen_tmp_path.txt");
    file.open(QIODevice::ReadOnly | QIODevice::Text);
    QByteArray bytes = file.readAll();
    QString screenPath = QString::fromUtf8(bytes);
    qDebug() << screenPath;
    QString arg = "";
    QString picturePath = screenPath;
    if(picturePath != "") {
        QFile file(picturePath);
        if(!file.open(QIODevice::ReadOnly | QIODevice::Truncate)) {
            return;
        }
        QByteArray fileValue = file.readAll();
        file.close();
        QString fileBase64 = QString(fileValue.toBase64());

        Message message;
        message.time = QDateTime::currentDateTime();
        message.src = protocol->me.username;
        message.dst = this->partnerUsername;
        message.type = "picture";
        message.text = fileBase64;
        protocol->sendFriendMessage(message);
        record.insertRecordByUsername(protocol->me.username, this->partnerUsername, message);
        refreshMessage();
    }
}
