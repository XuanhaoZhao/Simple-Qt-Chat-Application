#include "signinwindow.h"
#include "ui_signinwindow.h"
#include "screenshot.h"

#include <QIcon>
#include <QImage>
#include <QPixmap>
#include <QTextCodec>

SignInWindow::SignInWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::SignInWindow) {
    ui->setupUi(this);
    this->setWindowFlags(this->windowFlags() &~ Qt::WindowMaximizeButtonHint);

    this->setWindowIcon(QIcon("://favicon.ico"));
    ui->username->setPlaceholderText("Username ...");
    ui->password->setPlaceholderText("Password ...");
    ui->username->setFont(QFont("Helvetica", 16));
    ui->password->setFont(QFont("Helvetica", 16));
    QPixmap username_icon("://assets/iconbit.png");
    QPixmap username_pix = username_icon.scaled(ui->label->size(),Qt::KeepAspectRatio);
    ui->label->setPixmap(username_pix);

    QPixmap password_icon("://assets/lock5.png");
    QPixmap password_pix = password_icon.scaled(ui->label->size(),Qt::KeepAspectRatio);
    ui->label_2->setPixmap(password_pix);

    ui->signIn->setFont(QFont("Helvetica", 16));
    ui->faceSignIn->setFont(QFont("Helvetica", 10));
    ui->signUp->setFont(QFont("Helvetica", 10));

    ui->password->setEchoMode(QLineEdit::Password);

    ui->pushButton->setCursor(Qt::PointingHandCursor);
    ui->pushButton->setCheckable(true);
    QPixmap show_icon("://assets/show.png");
    QPixmap show_pix = show_icon.scaled(ui->pushButton->size(),Qt::KeepAspectRatio);
    QPixmap hide_icon("://assets/hide.png");
    QPixmap hide_pix = hide_icon.scaled(ui->pushButton->size(),Qt::KeepAspectRatio);
    ui->pushButton->setIcon(QIcon(hide_pix));
    ui->pushButton->setStyleSheet("border: 0px");
    connect(ui->pushButton, &QPushButton::toggled, [=](bool checked) {
        if (checked)
        {
            ui->password->setEchoMode(QLineEdit::Normal);
            ui->pushButton->setIcon(QIcon(show_pix));
        }
        else
        {
            ui->password->setEchoMode(QLineEdit::Password);
            ui->pushButton->setIcon(QIcon(hide_pix));
        }
    });


    protocol = new Protocol();
    protocol->connectServer("ws://127.0.0.1:3000");
    connect(protocol, &Protocol::signInSuccess, this, &SignInWindow::signInSuccess);
    connect(protocol, &Protocol::signInFailed, this, &SignInWindow::signInFailed);

//    connect(ui->password, &QLineEdit::returnPressed, this, &SignInWindow::on_signIn_clicked);
}

SignInWindow::~SignInWindow() {
    delete protocol;
    delete ui;
}

void SignInWindow::on_signIn_clicked() {
    if(ui->username->text() != "" && ui->password->text() != "") {
        protocol->sendSignIn(ui->username->text(), ui->password->text());
    } else {
        QMessageBox::critical(NULL, "NeuTalk", "Please input Username and Password!");
    }
}

void SignInWindow::on_signUp_clicked() {
    if(!signUpWindow) {
        signUpWindow = new SignUpWindow(this);
        signUpWindow->setProtocol(protocol);
    }
    signUpWindow->show();
}

void SignInWindow::signInSuccess() {
    if(faceSignInWindow && faceSignInWindow->isVisible()) {
        faceSignInWindow->close();
    }
    this->close();
    if(!mainWindow) {
        mainWindow = new MainWindow();
        mainWindow->setProtocol(protocol);
    }
    mainWindow->show();
}

void SignInWindow::signInFailed() {
    QMessageBox::critical(NULL, "NeuTalk", "Sign In Failed!");
}

void SignInWindow::on_faceSignIn_clicked() {
    if(!faceSignInWindow) {
        faceSignInWindow = new FaceSignInWindow(this);
        faceSignInWindow->setProtocol(protocol);
    }
    faceSignInWindow->initCamera();
    faceSignInWindow->show();
}

void SignInWindow::on_pushButton_2_clicked()
{
    qDebug() << "Capturing...";
#if (QT_VERSION <= QT_VERSION_CHECK(5,0,0))
#if _MSC_VER
    QTextCodec *codec = QTextCodec::codecForName("gbk");
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
#endif
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);
    QTextCodec::setCodecForTr(codec);
#else
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
    QTextCodec::setCodecForLocale(codec);
#endif
    ScreenWidget *scr = new ScreenWidget(nullptr);
    scr->showFullScreen();
}
