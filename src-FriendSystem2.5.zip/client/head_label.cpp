#include "head_label.h"
#include<QFile>
head_label::head_label(QWidget *parent) : QLabel(parent)
{

}
void head_label:: mouseReleaseEvent(QMouseEvent *ev)
{
    if(ev->button() ==Qt::LeftButton)
    {
        QString filename = QFileDialog::getOpenFileName(this,"Please choose the picture to replace head image","./");
        emit image_change(filename);
    }
}
