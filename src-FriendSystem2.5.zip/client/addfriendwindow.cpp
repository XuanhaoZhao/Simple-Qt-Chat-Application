#include "addfriendwindow.h"
#include "ui_addfriendwindow.h"

#include <QMessageBox>

AddFriendWindow::AddFriendWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AddFriendWindow)
{
    ui->setupUi(this);
    ui->addFriend->setText("Search & Add");
    ui->addFriend->resize(100, 50);
}

void AddFriendWindow::setProtocol(Protocol *protocol)
{
    this->protocol = protocol;
    connect(this->protocol, &Protocol::duplicatedFriends, this, &AddFriendWindow::addFailed_FriendExists);
}

AddFriendWindow::~AddFriendWindow()
{
    delete ui;
}

void AddFriendWindow::on_addFriend_clicked()
{
    QString target = ui->lineEdit->text();
    this->protocol->sendAddFriendRequest(target);
}

void AddFriendWindow::addFailed_FriendExists()
{
    QMessageBox::critical(NULL, "NeuTalk", "Add Failed! The User has been your friend already!");
}
