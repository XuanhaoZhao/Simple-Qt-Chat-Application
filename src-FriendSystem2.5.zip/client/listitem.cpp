#include "listitem.h"
#include "ui_listitem.h"

ListItem::ListItem(QWidget *parent, QString username) :
    QWidget(parent),
    ui(new Ui::ListItem)
{
    ui->setupUi(this);
    ui->label_7->setText(username);
    ui->label_7->setFont(QFont("Helvetica", 16));

    QPixmap accept_icon("://assets/right.png");
    QPixmap accept_pix = accept_icon.scaled(ui->pushButton_10->size(),Qt::KeepAspectRatio);
    ui->pushButton_10->setIcon(accept_pix);
    ui->pushButton_10->setProperty("username", username);

    QPixmap refuse_icon("://assets/del.png");
    QPixmap refuse_pix = refuse_icon.scaled(ui->pushButton_11->size(),Qt::KeepAspectRatio);
    ui->pushButton_11->setIcon(refuse_pix);
    ui->pushButton_11->setProperty("username", username);

    connect(ui->pushButton_10, &QPushButton::clicked,
            [=](){
        emit needRefreshFriendRequestList();
        emit needRequestValidation();
        this->close();
    });
    connect(ui->pushButton_11, &QPushButton::clicked,
            [=](){
        emit needRefreshFriendRequestList();
        this->close();
    });
}

ListItem::~ListItem()
{
    delete ui;
}
