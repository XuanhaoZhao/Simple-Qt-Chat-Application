#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QPixmap>
#include<QByteArray>
#include"head_label.h"
#include"frienditem.h"


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    this->setWindowFlags(this->windowFlags() &~ Qt::WindowMaximizeButtonHint);
}

void MainWindow::setProtocol(Protocol *protocol) {
    this->protocol = protocol;
    this->setWindowTitle("NeuTalk " + this->protocol->me.username);
    ui->label->setText(this->protocol->me.nickname);
    QByteArray str = this->protocol->me.headImage.toUtf8();
qDebug()<<"Receiving Head Image ..."  << this->protocol->me.headImage.size();
    QByteArray imgData = QByteArray::fromBase64(str);//字符串转图像数据
    QPixmap pixmap;
    pixmap.loadFromData(imgData);//从数据载入图像
    ui->label_head->setPixmap(pixmap);
    ui->label_head->setScaledContents(true);

    connect(this->protocol, SIGNAL(getFriendsListSuccess()), this, SLOT(getFriendsListSuccess()));
    connect(this->protocol, SIGNAL(needRefreshFriendsList()), this, SLOT(getFriendsListSuccess()));
    connect(this->protocol, SIGNAL(getGroupsListSuccess()), this, SLOT(getGroupsListSuccess()));
    connect(this->protocol, SIGNAL(needRefreshGroupsList()), this, SLOT(getGroupsListSuccess()));
    connect(ui->label_head, SIGNAL(image_change(QString)), this->protocol, SLOT(image_change(QString)));
    connect(this->protocol,SIGNAL(proimage_change(QString)),this,SLOT(windowchange(QString)));
    connect(this->protocol, &Protocol::getFriendsHeadImageSuccess, this, &MainWindow::getFriendsHeadImageSuccess);
    connect(this, &MainWindow::recvFriendsListSuccess, this->protocol, &Protocol::sendGetFriendsHeadImage);

    this->protocol->sendGetFriendsList();
    this->protocol->sendGetGroupsList();

    ui->list->setItemText(0,"Friends");
    ui->list->setItemText(1,"Groups");

}
void MainWindow::windowchange(QString)
{
    QByteArray str = this->protocol->me.headImage.toUtf8();
qDebug()<< this->protocol->me.headImage.size();
    QByteArray imgData = QByteArray::fromBase64(str);//字符串转图像数据
    QPixmap pixmap;
    pixmap.loadFromData(imgData);//从数据载入图像
    ui->label_head->setPixmap(pixmap);
    ui->label_head->setScaledContents(true);
}

void MainWindow::on_addFriend_clicked()
{
    if (!addFriendWindow) {
        addFriendWindow = new AddFriendWindow(this);
        addFriendWindow->setProtocol(protocol);
    }
    addFriendWindow->show();
}

void MainWindow::on_validation_clicked()
{
    if (!requestValidationWindow) {
        requestValidationWindow = new RequestValidationWindow (this);
        requestValidationWindow->setProtocol(protocol);
    }
    requestValidationWindow->show();
}

void MainWindow::on_createGroup_clicked()
{
    if(!createGroupWindow) {
        createGroupWindow = new CreateGroupWindow(this);
        createGroupWindow->setProtocol(protocol);
    }
    createGroupWindow->show();
    connect(this->protocol, &Protocol::creatGroupSuccess,this,&MainWindow::refreshGroupsList);
}

void MainWindow::refreshGroupsList()
{
qDebug() << "refreshGroupsList";
    QWidget *widget = ui->list->widget(1);
    if(widget->layout()) {
        delete widget->layout();
    }
    QVBoxLayout *layout = new QVBoxLayout();

    for(std::vector<QString>::iterator it = protocol->groupsName.begin(); it != protocol->groupsName.end(); ++it) {
        QString format;
        if(protocol->groupsNewMessage[*it] > 0) {
            format = QString("%1 (%2)").arg(*it).arg(protocol->groupsNewMessage[*it]);
        } else {
            format = QString("%1").arg(*it);
        }
        QPushButton *button = new QPushButton(format);
        button->setProperty("groupname", *it);

        layout->addWidget(button, 0, Qt::AlignTop);
        connect(button, SIGNAL(clicked(bool)), this, SLOT(groupClicked()));
    }
    layout->addStretch(50);
    widget->setLayout(layout);
}

MainWindow::~MainWindow() {
    delete ui;
}


void MainWindow::refreshFriendsList() {
        QWidget *widget = ui->list->widget(0);
        if(widget->layout()) {
            delete widget->layout();
        }
        QVBoxLayout *layout = new QVBoxLayout();
        ui->friendlist->clear();


        for(std::vector<QString>::iterator it = protocol->friendsUsername.begin(); it != protocol->friendsUsername.end(); ++it) {
            QString format;
            if(protocol->friendsNewMessage[*it] > 0) {
                format = QString("%1 (%2)").arg(*it).arg(protocol->friendsNewMessage[*it]);
            } else {
                format = QString("%1").arg(*it);
            }


            QListWidgetItem *item=new QListWidgetItem(ui->friendlist);
            item->setSizeHint(QSize(100, 100));
            Frienditem * list = new Frienditem(ui->friendlist,*it,protocol);
            ui->friendlist->addItem(item);
            ui->friendlist->setItemWidget(item,list);

            connect(list->getButton(), SIGNAL(clicked(bool)), this, SLOT(friendClicked()));
        }
        layout->addStretch(50);
        widget->setLayout(layout);
}

//void MainWindow::refreshFriendsList() {
//        QWidget *widget = ui->list->widget(0);
//        if(widget->layout()) {
//            delete widget->layout();
//        }
//        QVBoxLayout *layout = new QVBoxLayout();

//        for(std::vector<QString>::iterator it = protocol->friendsUsername.begin(); it != protocol->friendsUsername.end(); ++it) {
//            QString format;
//            if(protocol->friendsNewMessage[*it] > 0) {
//                format = QString("%1 (%2)").arg(*it).arg(protocol->friendsNewMessage[*it]);
//            } else {
//                format = QString("%1").arg(*it);
//            }
//            QPushButton *button = new QPushButton(format);
//            button->setProperty("username", *it);
//            button->setProperty("nickname", protocol->friendsNickname[*it]);
//            button->setProperty("headImage", protocol->friendsHeadImage[*it]);
//            layout->addWidget(button, 0, Qt::AlignTop);
//            connect(button, SIGNAL(clicked(bool)), this, SLOT(friendClicked()));
//        }
//        layout->addStretch(50);
//        widget->setLayout(layout);
//}

void MainWindow::getFriendsListSuccess() {
    emit recvFriendsListSuccess();
}

void MainWindow::getGroupsListSuccess()
{
    this->refreshGroupsList();
    emit recvGroupsListSuccess();
}

void MainWindow::friendClicked() {
    if(!talkWindow) {
        talkWindow = new TalkWindow(this);
        talkWindow->setProtocol(protocol);
    }
    protocol->openWindowWith = sender()->property("username").toString();
    protocol->friendsNewMessage[sender()->property("username").toString()] = 0;
    this->refreshFriendsList();
    talkWindow->setOthers(false, sender()->property("username").toString(), sender()->property("nickname").toString(), sender()->property("headImage").toString());
    talkWindow->show();
}

void MainWindow::getFriendsHeadImageSuccess()
{
    qDebug() << "Main " << "getFriendsHeadImageSuccess";
//    for(std::vector<QString>::iterator it = protocol->friendsUsername.begin(); it != protocol->friendsUsername.end(); ++it)
//    {
//        QString headImage = protocol->friendsHeadImage[*it];
//        qDebug() << "Head Image from " << *it << " : " <<headImage.size();
//        QByteArray byte_array1 = QByteArray::fromBase64(headImage.toLocal8Bit());
//        qDebug() << byte_array1.length();
//        QPixmap pix;
//        pix.loadFromData(byte_array1, "JPG");
//        QPixmap pix_scaled = pix.scaled(512, 512 ,Qt::KeepAspectRatio);
//        ui->label->resize(600, 600);
//        ui->label->setPixmap(pix);
//        qDebug() << pix.size();
//    }
    this->refreshFriendsList();
}

//void MainWindow::on_labelHead_clicked()
//{
//    QString filename = QFileDialog::getOpenFileName(this,"Please choose the picture to replace head image","./");
//    emit image_change(filename);
//}

void MainWindow::on_closeButton_clicked()
{
    this->close();
}

void MainWindow::groupClicked()
{
    if(!groupWindow) {
        groupWindow = new GroupWindow(this);
        groupWindow->setProtocol(protocol);
    }
    protocol->openWindowWith = sender()->property("groupname").toString();
    protocol->groupsNewMessage[sender()->property("groupname").toString()] = 0;
    this->refreshGroupsList();

    groupWindow->setOthers(true, sender()->property("groupname").toString(), "");
    groupWindow->show();
}
