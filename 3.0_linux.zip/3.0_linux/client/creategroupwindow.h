#ifndef CREATEGROUPWINDOW_H
#define CREATEGROUPWINDOW_H

#include <QDialog>
#include <protocol.h>
namespace Ui {
class CreateGroupWindow;
}

class CreateGroupWindow : public QDialog
{
    Q_OBJECT

public:
    explicit CreateGroupWindow(QWidget *parent = nullptr);
    ~CreateGroupWindow();
    void setProtocol(Protocol*);

public slots:

    void pushButtonConfirm();

private:
    Ui::CreateGroupWindow *ui;
    Protocol *protocol;


};

#endif // CREATEGROUPWINDOW_H
