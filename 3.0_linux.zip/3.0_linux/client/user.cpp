#include "user.h"

User::User(QString username, QString password, QString nickname, QString groupslist, QString headImage, QString friendsList) {
    this->username = username;
    this->password = password;
    this->nickname = nickname;
    this->groupslist = groupslist;
    this->headImage = headImage;
    this->friendsList = friendsList;
}
