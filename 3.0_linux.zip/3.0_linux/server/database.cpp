#include "database.h"

Database::Database() {
    if(QSqlDatabase::contains("qt_sql_default_connection")) {
        db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE");
    }
    db.setDatabaseName("server.db");

    if (!db.open()) {
qDebug() << "Error: Failed to connect database." << db.lastError();
    } else {
qDebug() << "Succeed to connect database.";
    }

    QSqlQuery query;

    if(!query.exec("create table if not exists users(username varchar primary key, password varchar, nickname varchar, groupslist varchar, headimage varchar, friendslist varchar);")) {
qDebug() << "Error: Fail to create table."<< query.lastError();
    } else {
qDebug() << "Table users OK!";
    }

//    if(!query.exec("create table if not exists groups(id int primary key, nickname varchar, owner varchar, members varchar);")) {
//        qDebug() << "Error: Fail to create table."<< query.lastError();
//    } else {
//        qDebug() << "Table groups OK!";
//    }
    query.finish();
    QSqlQuery query2;

    if(!query2.exec("create table if not exists groups(groupname varchar primary key, creator varchar, groupimage, memberslist varchar);")) {
        qDebug() << "Error: Fail to create group table."<< query2.lastError();
    } else {
        qDebug() << "Table group OK!";
    }
    query2.finish();
}

Database::~Database() {
    db.close();
}

std::vector<User> Database::selectUser() {
    QSqlQuery query;
    std::vector<User> retval;
    if(query.exec("select * from users;")) {
        while(query.next()) {
            User user;
            user.username = query.value(0).toString();
            user.password = query.value(1).toString();
            user.nickname = query.value(2).toString();
            user.groupsList = query.value(3).toString();
            user.headImage = query.value(4).toString();
            user.friendsList = query.value(5).toString();
            retval.push_back(user);
        }
        return retval;
    }
qDebug() << query.lastError();
    query.finish();
    return retval;
}

std::vector<Group> Database::selectGroup()
{
    QSqlQuery query;
    std::vector<Group> retval;
    if(query.exec("select * from groups;")) {
        while(query.next()) {
            Group group;
            group.groupName = query.value(0).toString();
            group.creator = query.value(1).toString();
            group.groupImage = query.value(2).toString();
            group.membersList = query.value(3).toString();
            retval.push_back(group);
        }
        return retval;
    }
qDebug() << query.lastError();
    query.finish();
    return retval;
}

User *Database::selectUserByUsername(QString username) {
    QSqlQuery query;
qDebug() << "username : " << username;
    query.prepare("select * from users where username == :username;");
    query.bindValue(":username", QString(username));
    query.exec();

    if(query.next()) {
        User *retval = new User;
        retval->username = username;
        retval->password = query.value(1).toString();
        retval->nickname = query.value(2).toString();
        retval->groupsList = query.value(3).toString();
        retval->headImage = query.value(4).toString();
        retval->friendsList = query.value(5).toString();
        return retval;
    }

qDebug() << query.lastError();
    query.finish();
    return NULL;
}

Group *Database::selectGroupByGroupName(QString groupname)
{
    QSqlQuery query;
    query.prepare("select * from groups where groupname == :groupname;");
    query.bindValue(":groupname", QString(groupname));
    query.exec();

    if(query.next()) {
        Group *retval = new Group;
        retval->groupName = groupname;
        retval->creator = query.value(1).toString();
        retval->groupImage = query.value(2).toString();
        retval->membersList = query.value(3).toString();
        return retval;
    }

qDebug() << query.lastError();
    query.finish();
    return NULL;
}

bool Database::insertUser(User user) {
    QSqlQuery query;
    query.prepare("insert into users (username, password, nickname, groupslist, headimage, friendslist) values (:username, :password, :nickname, :groupslist, :headimage, :friendslist);");
    query.bindValue(":username", user.username);
    query.bindValue(":password", user.password);
    query.bindValue(":nickname", user.nickname);
    query.bindValue(":groupslist", user.groupsList);
    query.bindValue(":headimage", user.headImage);
    query.bindValue(":friendslist", user.friendsList);
qDebug() << "binding headImage ..." << user.headImage.size();

    if(query.exec()) {
        return true;
    }

qDebug() << query.lastError();
    query.finish();
    return false;
}

bool Database::changeUserImg(User user) {
    QSqlQuery query;
    bool isok_query = query.prepare("update users set headimage = :headimage where username = :username ;");

    if(true == isok_query)
    {
qDebug()<<"change query is ok";
    } else {
qDebug()<<"change query is wrong";
    }
//qDebug()<<user.headimage;
    query.bindValue(":username", user.username);
    query.bindValue(":headimage", user.headImage);
    if(query.exec()) {
        return true;
    }

qDebug() << query.lastError();
    query.finish();
    return false;
}

bool Database::connectUsers(QString username1, QString username2)
{
    User *userA = selectUserByUsername(username1);
    User *userB = selectUserByUsername(username2);
    if ((userA) && (userB))
    {
        QString newFriendsListA = (userA->friendsList == "") ? (userB->username)  : (userA->friendsList + "," + userB->username);
        QString newFriendsListB = (userB->friendsList == "") ? (userA->username)  : (userB->friendsList + "," + userA->username);
        QSqlQuery queryA, queryB;

        queryA.prepare("update users set friendslist = :friendslist where username = :username ;");
        queryB.prepare("update users set friendslist = :friendslist where username = :username ;");

        queryA.bindValue(":friendslist", newFriendsListA);
        queryA.bindValue(":username", userA->username);

        queryB.bindValue(":friendslist", newFriendsListB);
        queryB.bindValue(":username", userB->username);

        if(queryA.exec() && queryB.exec()) {
            return true;
        }
qDebug() << queryA.lastError();
         queryA.finish();
qDebug() << queryB.lastError();
         queryB.finish();
    } else {
qDebug() << "Users Not Found";
    }
    return false;
}

bool Database::insertGroup(Group group)
{
    QSqlQuery query;

    bool preIsOk =  query.prepare(QString("insert into groups (groupname, creator, groupimage, memberslist) values (:groupname ,:creator ,:groupimage, :memberslist);"));
    if(preIsOk) {
qDebug()<<"prepare done";
    } else {
qDebug()<<"prepare failed";
    }
        query.bindValue(":groupname", group.groupName);
        query.bindValue(":creator", group.creator);
        query.bindValue(":groupimage", group.groupImage);
        query.bindValue(":memberslist", group.membersList);

        if(query.exec()) {
            query.finish();
qDebug()<<"new group inserted"<<group.groupName << " " <<group.creator << " " << group.groupImage.size();
            return true;
        }
        qDebug() << "Error: Group Fail to insert group." << query.lastError();
        query.finish();

    return false;
}

bool Database::changeUserGroupnamelist(QString username, QString groupsList)
{
    QSqlQuery query;
    query.prepare("update users set groupslist = :groupslist where username == :username;");
    query.bindValue(":username", username);
    query.bindValue(":groupslist", groupsList);
    query.exec();


    if(query.exec()) {
        return true;
    }

    qDebug() << query.lastError();
    query.finish();
    return false;
}

bool Database::inviteGroupMember(QString groupname, QString username)
{
qDebug() << "inviteGroupMember";
    Group *group = selectGroupByGroupName(groupname);
    QString memberslist = group->membersList + "," + username;
qDebug() << memberslist;
    User *user = selectUserByUsername(username);
    QString groupslist = user->groupsList;
    if (groupslist == "") {
        groupslist = groupname;
    } else {
        groupslist = groupslist + "," + groupname;
    }
qDebug() << groupslist;

    QSqlQuery q_group, q_user;
    q_group.prepare("update groups set memberslist = :memberslist where groupname == :groupname;");
    q_group.bindValue(":memberslist", memberslist);
    q_group.bindValue(":groupname", groupname);

    q_user.prepare("update users set groupslist = :groupslist where username == :username");
    q_user.bindValue(":groupslist", groupslist);
    q_user.bindValue(":username", username);

    if(q_group.exec() && q_user.exec()) {
        return true;
    }
qDebug() << q_group.lastError();
     q_group.finish();
qDebug() << q_user.lastError();
     q_user.finish();
    return false;
}
